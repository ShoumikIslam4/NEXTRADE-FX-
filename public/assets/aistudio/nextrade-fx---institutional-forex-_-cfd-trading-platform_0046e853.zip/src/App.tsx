/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { ToastProvider } from './contexts/ToastContext';
import { TradingProvider } from './contexts/TradingContext';
import { ToastContainer } from './components/common/ToastContainer';

// Layouts
import { PublicLayout } from './layouts/PublicLayout';
import { TraderLayout } from './layouts/TraderLayout';
import { AdminLayout } from './layouts/AdminLayout';

// Public Pages
import { HomePage } from './pages/public/HomePage';
import { 
  MarketsPage, ForexPage, CommoditiesPage, IndicesPage, PricingPage 
} from './pages/public/MarketsPages';
import { 
  TradingPage, PlatformsPage, AccountTypesPage, AboutPage, ContactPage, FaqPage 
} from './pages/public/TradingAndCompanyPages';
import { 
  PublicEconomicCalendarPage, PublicNewsPage, PublicAnalysisPage, 
  PublicSignalsPage, PublicEducationPage 
} from './pages/public/ResearchAndEducationPages';
import { 
  LoginPage, RegisterPage, ForgotPasswordPage, 
  PrivacyPolicyPage, TermsPage, RiskDisclosurePage 
} from './pages/public/AuthAndLegalPages';

// Trader Pages
import { TraderOverviewPage } from './pages/trader/TraderOverviewPage';
import { TradingTerminalPage } from './pages/trader/TradingTerminalPage';
import { TradingAccountsPage } from './pages/trader/TradingAccountsPage';
import { PositionsPage, PendingOrdersPage, TradeHistoryPage } from './pages/trader/PositionsAndOrdersPages';
import { 
  WatchlistPage, TraderAnalysisPage, TraderSignalsPage, TraderCalendarPage 
} from './pages/trader/WatchlistAndAnalyticsPages';
import { 
  WalletPage, DepositPage, WithdrawalPage, TransactionsPage 
} from './pages/trader/WalletAndFinancePages';
import { 
  KycPage, NotificationsPage, ReportsPage, TicketsPage, 
  ProfilePage, AccountSettingsPage, SecuritySettingsPage 
} from './pages/trader/AccountAndSupportPages';

// Admin Pages
import { AdminOverviewPage } from './pages/admin/AdminOverviewPage';
import { UserManagementPage, KycManagementPage, TradingAccountsAdminPage } from './pages/admin/AdminUsersAndKycPages';
import { 
  TradingMonitorPage, OrdersManagementPage, AdminPositionsPage, 
  AdminTransactionsPage, AdminDepositsPage, AdminWithdrawalsPage, PaymentMethodsPage 
} from './pages/admin/AdminDealingAndFinancePages';
import { 
  CurrencyPairsAdminPage, SpreadManagementPage, LeverageSettingsPage, 
  CommissionSettingsPage, SignalsManagementPage, NewsManagementPage, 
  CalendarManagementPage, EducationManagementPage, CmsContentPage, 
  SupportTicketsAdminPage, StaffManagementPage, RolesPermissionsPage, 
  AuditLogsPage, GeneralSettingsPage 
} from './pages/admin/AdminConfigAndContentPages';

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <TradingProvider>
          <BrowserRouter>
            <Routes>
              {/* 1. PUBLIC WEBSITE ROUTES */}
              <Route path="/" element={<PublicLayout />}>
                <Route index element={<HomePage />} />
                <Route path="about" element={<AboutPage />} />
                <Route path="markets" element={<MarketsPage />} />
                <Route path="markets/forex" element={<ForexPage />} />
                <Route path="markets/commodities" element={<CommoditiesPage />} />
                <Route path="markets/indices" element={<IndicesPage />} />
                <Route path="trading" element={<TradingPage />} />
                <Route path="account-types" element={<AccountTypesPage />} />
                <Route path="pricing" element={<PricingPage />} />
                <Route path="platforms" element={<PlatformsPage />} />
                <Route path="economic-calendar" element={<PublicEconomicCalendarPage />} />
                <Route path="news" element={<PublicNewsPage />} />
                <Route path="analysis" element={<PublicAnalysisPage />} />
                <Route path="signals" element={<PublicSignalsPage />} />
                <Route path="education" element={<PublicEducationPage />} />
                <Route path="faq" element={<FaqPage />} />
                <Route path="contact" element={<ContactPage />} />
                <Route path="login" element={<LoginPage />} />
                <Route path="register" element={<RegisterPage />} />
                <Route path="forgot-password" element={<ForgotPasswordPage />} />
                <Route path="privacy" element={<PrivacyPolicyPage />} />
                <Route path="terms" element={<TermsPage />} />
                <Route path="risk-disclosure" element={<RiskDisclosurePage />} />
              </Route>

              {/* 2. TRADER DASHBOARD ROUTES */}
              <Route path="/trader" element={<TraderLayout />}>
                <Route index element={<Navigate to="/trader/overview" replace />} />
                <Route path="overview" element={<TraderOverviewPage />} />
                <Route path="terminal" element={<TradingTerminalPage />} />
                <Route path="accounts" element={<TradingAccountsPage />} />
                <Route path="positions" element={<PositionsPage />} />
                <Route path="pending-orders" element={<PendingOrdersPage />} />
                <Route path="history" element={<TradeHistoryPage />} />
                <Route path="watchlist" element={<WatchlistPage />} />
                <Route path="analysis" element={<TraderAnalysisPage />} />
                <Route path="signals" element={<TraderSignalsPage />} />
                <Route path="calendar" element={<TraderCalendarPage />} />
                <Route path="wallet" element={<WalletPage />} />
                <Route path="deposit" element={<DepositPage />} />
                <Route path="withdrawal" element={<WithdrawalPage />} />
                <Route path="transactions" element={<TransactionsPage />} />
                <Route path="kyc" element={<KycPage />} />
                <Route path="notifications" element={<NotificationsPage />} />
                <Route path="reports" element={<ReportsPage />} />
                <Route path="tickets" element={<TicketsPage />} />
                <Route path="profile" element={<ProfilePage />} />
                <Route path="settings" element={<AccountSettingsPage />} />
                <Route path="security" element={<SecuritySettingsPage />} />
              </Route>

              {/* 3. ADMIN DASHBOARD ROUTES */}
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<Navigate to="/admin/overview" replace />} />
                <Route path="overview" element={<AdminOverviewPage />} />
                <Route path="users" element={<UserManagementPage />} />
                <Route path="kyc" element={<KycManagementPage />} />
                <Route path="accounts" element={<TradingAccountsAdminPage />} />
                <Route path="monitor" element={<TradingMonitorPage />} />
                <Route path="orders" element={<OrdersManagementPage />} />
                <Route path="positions" element={<AdminPositionsPage />} />
                <Route path="transactions" element={<AdminTransactionsPage />} />
                <Route path="deposits" element={<AdminDepositsPage />} />
                <Route path="withdrawals" element={<AdminWithdrawalsPage />} />
                <Route path="payment-methods" element={<PaymentMethodsPage />} />
                <Route path="currency-pairs" element={<CurrencyPairsAdminPage />} />
                <Route path="spreads" element={<SpreadManagementPage />} />
                <Route path="leverage" element={<LeverageSettingsPage />} />
                <Route path="commissions" element={<CommissionSettingsPage />} />
                <Route path="signals" element={<SignalsManagementPage />} />
                <Route path="news" element={<NewsManagementPage />} />
                <Route path="calendar" element={<CalendarManagementPage />} />
                <Route path="education" element={<EducationManagementPage />} />
                <Route path="cms" element={<CmsContentPage />} />
                <Route path="tickets" element={<SupportTicketsAdminPage />} />
                <Route path="notifications" element={<NotificationsPage />} />
                <Route path="reports" element={<ReportsPage />} />
                <Route path="staff" element={<StaffManagementPage />} />
                <Route path="roles" element={<RolesPermissionsPage />} />
                <Route path="audit-logs" element={<AuditLogsPage />} />
                <Route path="settings" element={<GeneralSettingsPage />} />
              </Route>

              {/* Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>

            {/* Global Floating Toast Alert Container */}
            <ToastContainer />
          </BrowserRouter>
        </TradingProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
