import React, { useState } from 'react';
import { useTrading } from '../../contexts/TradingContext';
import { 
  ShieldCheck, ShieldAlert, CheckCircle2, Clock, 
  FileText, User, Building, AlertCircle, X, ArrowRight, ArrowLeft 
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveOnboardingModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { liveApplication, submitLiveApplication, switchAccount, accounts } = useTrading();

  const [step, setStep] = useState<number>(1);
  const [formData, setFormData] = useState({
    fullName: liveApplication.fullName || '',
    email: liveApplication.email || '',
    phone: liveApplication.phone || '',
    country: liveApplication.country || 'United States',
    employmentStatus: liveApplication.employmentStatus || 'Employed',
    annualIncome: liveApplication.annualIncome || '$100,000 - $250,000',
    tradingExperience: liveApplication.tradingExperience || '3-5 Years (Forex & Derivatives)',
    riskTolerance: liveApplication.riskTolerance || 'Moderate',
    idType: liveApplication.idType || 'Passport',
    idNumber: liveApplication.idNumber || '',
    proofOfAddress: liveApplication.proofOfAddress || 'Bank Statement'
  });

  if (!isOpen) return null;

  const liveAccount = accounts.find(a => a.mode === 'LIVE');
  const isAlreadySubmitted = liveApplication.status !== 'NOT_APPLIED';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitLiveApplication(formData as any);
    setStep(4); // Move to Verification Pending view
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#111827] border border-blue-500/40 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#151F30] border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Live Institutional & Retail Trading Onboarding</h2>
              <p className="text-[11px] text-slate-400">KYC Compliance & Broker Connection Registration</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Regulatory & Financial Safety Notice Banner */}
        <div className="px-6 py-3 bg-[#0B1220] border-b border-slate-800 text-xs">
          <div className="flex items-start gap-2 text-amber-300">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
            <div className="text-[11px] leading-relaxed text-slate-300">
              <strong className="text-amber-300">Broker Connectivity Notice:</strong> Live order execution and real-money deposits are safely disabled pending regulatory approval and legitimate prime-brokerage liquidity bridge verification. You may complete onboarding now for future institutional account authorization.
            </div>
          </div>
        </div>

        {/* Content Stages */}
        <div className="p-6">
          {/* If already submitted and user opened it, show verification-pending directly */}
          {(isAlreadySubmitted && step === 1) ? (
            <div className="space-y-6">
              <div className="text-center py-4 space-y-3">
                <div className="w-14 h-14 rounded-full bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 mx-auto">
                  <Clock className="w-7 h-7 stroke-[2]" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30">
                    APPLICATION {liveApplication.status.replace('_', ' ')}
                  </span>
                  <h3 className="text-lg font-bold text-white mt-2">Institutional Verification Pending</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Your live trading application has been received and logged under reference #{liveApplication.id}. Compliance review takes approximately 24 to 48 hours.
                  </p>
                </div>
              </div>

              {/* Status Details Grid */}
              <div className="bg-[#151F30] border border-slate-800 rounded-xl p-4 divide-y divide-slate-800/80 text-xs">
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">Applicant:</span>
                  <span className="font-semibold text-white">{liveApplication.fullName} ({liveApplication.email})</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">Assigned Live Account:</span>
                  <span className="font-mono text-blue-400 font-bold">{liveAccount?.accountNumber || 'NX-LIVE-PENDING'}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">Submission Date:</span>
                  <span className="font-mono text-slate-200">{liveApplication.submittedAt}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">KYC Document Status:</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {liveApplication.idType} ({liveApplication.idNumber || 'Verified'}) Submitted
                  </span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">Live Broker Status:</span>
                  <span className="text-amber-400 font-semibold">Awaiting Authorized Liquidity Bridge</span>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="flex-1 py-2.5 rounded-lg border border-slate-700 bg-[#0B1220] hover:bg-slate-800 text-slate-300 font-semibold text-xs transition-colors"
                >
                  Update Information
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (liveAccount) switchAccount(liveAccount.id);
                    onClose();
                  }}
                  className="flex-1 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors"
                >
                  Switch to Live Account Workspace
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5 text-xs">
              {/* Step Indicators */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-[11px]">
                <div className="flex items-center gap-2">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold ${
                    step >= 1 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>1</span>
                  <span className={step === 1 ? 'text-white font-semibold' : 'text-slate-400'}>Personal Profile</span>
                </div>
                <div className="h-[1px] w-8 bg-slate-800" />
                <div className="flex items-center gap-2">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold ${
                    step >= 2 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>2</span>
                  <span className={step === 2 ? 'text-white font-semibold' : 'text-slate-400'}>Financial & Risk</span>
                </div>
                <div className="h-[1px] w-8 bg-slate-800" />
                <div className="flex items-center gap-2">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold ${
                    step >= 3 ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>3</span>
                  <span className={step === 3 ? 'text-white font-semibold' : 'text-slate-400'}>KYC Identity</span>
                </div>
              </div>

              {/* Step 1: Personal Profile */}
              {step === 1 && (
                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Applicant Personal Details</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Full Legal Name</label>
                      <input
                        type="text"
                        required
                        value={formData.fullName}
                        onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                        placeholder="e.g. John Doe"
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Corporate / Personal Email</label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={e => setFormData({ ...formData, email: e.target.value })}
                        placeholder="john@example.com"
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Contact Phone</label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Country of Tax Residence</label>
                      <select
                        value={formData.country}
                        onChange={e => setFormData({ ...formData, country: e.target.value })}
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="United States">United States</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Germany">Germany</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Australia">Australia</option>
                      </select>
                    </div>
                  </div>

                  <div className="pt-2 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg flex items-center gap-1.5"
                    >
                      <span>Continue to Financial Profile</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Step 2: Financial & Trading Experience */}
              {step === 2 && (
                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Financial Profile & Trading Knowledge</h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Employment Status</label>
                      <select
                        value={formData.employmentStatus}
                        onChange={e => setFormData({ ...formData, employmentStatus: e.target.value })}
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="Employed">Full-time Employed</option>
                        <option value="Self-Employed">Self-Employed / Entrepreneur</option>
                        <option value="Professional Trader">Professional Trader / Asset Manager</option>
                        <option value="Retired">Retired / Private Investor</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Estimated Annual Income (USD)</label>
                      <select
                        value={formData.annualIncome}
                        onChange={e => setFormData({ ...formData, annualIncome: e.target.value })}
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="$50,000 - $100,000">$50,000 - $100,000</option>
                        <option value="$100,000 - $250,000">$100,000 - $250,000</option>
                        <option value="$250,000 - $500,000">$250,000 - $500,000</option>
                        <option value="$500,000+">$500,000+ (Institutional)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Forex & CFD Trading Experience</label>
                      <select
                        value={formData.tradingExperience}
                        onChange={e => setFormData({ ...formData, tradingExperience: e.target.value })}
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="Less than 1 Year">Less than 1 Year</option>
                        <option value="1-3 Years">1 - 3 Years</option>
                        <option value="3-5 Years">3 - 5 Years</option>
                        <option value="5+ Years Institutional">5+ Years (Institutional / Fund)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Risk Appetite Classification</label>
                      <select
                        value={formData.riskTolerance}
                        onChange={e => setFormData({ ...formData, riskTolerance: e.target.value as any })}
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="Conservative">Conservative (Capital Preservation)</option>
                        <option value="Moderate">Moderate (Balanced Risk/Return)</option>
                        <option value="Aggressive">Aggressive (High Beta / Institutional)</option>
                      </select>
                    </div>
                  </div>

                  <div className="pt-2 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="px-3.5 py-2 border border-slate-700 text-slate-300 hover:text-white rounded-lg flex items-center gap-1.5"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setStep(3)}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg flex items-center gap-1.5"
                    >
                      <span>Proceed to Identity / KYC</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Identity Verification & KYC */}
              {step === 3 && (
                <div className="space-y-4">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Identity Document & Verification</h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Government ID Type</label>
                      <select
                        value={formData.idType}
                        onChange={e => setFormData({ ...formData, idType: e.target.value as any })}
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="Passport">Passport</option>
                        <option value="National ID">National Identity Card</option>
                        <option value="Driver License">Driver's License</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Document Number</label>
                      <input
                        type="text"
                        required
                        value={formData.idNumber}
                        onChange={e => setFormData({ ...formData, idNumber: e.target.value })}
                        placeholder="e.g. A92819401"
                        className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Proof of Residence (Past 90 Days)</label>
                    <select
                      value={formData.proofOfAddress}
                      onChange={e => setFormData({ ...formData, proofOfAddress: e.target.value })}
                      className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="Bank Statement">Certified Bank Statement</option>
                      <option value="Utility Bill">Utility Bill (Electricity, Water, Gas)</option>
                      <option value="Tax Assessment">Government Tax Assessment</option>
                    </select>
                  </div>

                  {/* Declaration checkbox */}
                  <label className="flex items-start gap-2 text-slate-300 cursor-pointer pt-2">
                    <input type="checkbox" required className="mt-1 rounded bg-slate-900 border-slate-700 text-blue-600" />
                    <span className="text-[11px] leading-relaxed">
                      I understand that real live market trading is subject to broker approval, identity validation, and execution connectivity. No real funds are debited or credited during this prototype onboarding.
                    </span>
                  </label>

                  <div className="pt-2 flex justify-between">
                    <button
                      type="button"
                      onClick={() => setStep(2)}
                      className="px-3.5 py-2 border border-slate-700 text-slate-300 hover:text-white rounded-lg flex items-center gap-1.5"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back</span>
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-md shadow-emerald-600/20 flex items-center gap-1.5"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Submit Live Account Application</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Step 4: Verification Pending view */}
              {step === 4 && (
                <div className="space-y-5 text-center py-4">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
                    <CheckCircle2 className="w-6 h-6 stroke-[2.5]" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Live Application Successfully Submitted</h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Your identity and financial profile have been securely recorded. Account status is now <span className="text-amber-400 font-semibold">UNDER REVIEW</span>.
                    </p>
                  </div>

                  <div className="bg-[#151F30] border border-slate-800 rounded-xl p-4 text-xs text-left space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Assigned Account Number:</span>
                      <span className="font-mono font-bold text-blue-400">{liveAccount?.accountNumber || 'NX-LIVE-10492'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Application Reference:</span>
                      <span className="font-mono text-white">{liveApplication.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Broker Authorization:</span>
                      <span className="text-amber-400 font-semibold">Awaiting Live Connectivity</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      if (liveAccount) switchAccount(liveAccount.id);
                      onClose();
                    }}
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors text-xs"
                  >
                    Go to Live Account Console
                  </button>
                </div>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
