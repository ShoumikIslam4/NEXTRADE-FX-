import React from 'react';
import { useTrading } from '../../contexts/TradingContext';
import { AlertTriangle, RefreshCw, X, ShieldAlert, Check } from 'lucide-react';

export const ResetDemoModal: React.FC = () => {
  const { resetModalOpen, setResetModalOpen, confirmResetDemoAccount, activeAccount } = useTrading();

  if (!resetModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md bg-[#111827] border border-amber-500/40 rounded-2xl p-6 shadow-2xl relative space-y-5">
        {/* Close Button */}
        <button
          onClick={() => setResetModalOpen(false)}
          className="absolute right-4 top-4 text-slate-400 hover:text-white transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <RefreshCw className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Reset Demo Account</h3>
            <p className="text-xs text-slate-400">Account #{activeAccount.accountNumber} ({activeAccount.type})</p>
          </div>
        </div>

        {/* Warning Body */}
        <div className="bg-[#151F30] border border-slate-800 rounded-xl p-4 space-y-2.5 text-xs">
          <div className="flex items-start gap-2 text-amber-300 font-semibold">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
            <span>Strict $1,000 Practice Rule Enforcement:</span>
          </div>
          <ul className="space-y-1.5 text-slate-300 list-disc list-inside text-[11px] leading-relaxed">
            <li>Your virtual demo balance will be restored to exactly <strong className="text-white">$1,000.00 USD</strong>.</li>
            <li>All open positions and pending orders on this demo account will be <strong className="text-rose-400">immediately cleared</strong>.</li>
            <li>Past trade history remains intact for performance auditing and review.</li>
            <li>This action cannot be undone.</li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => setResetModalOpen(false)}
            className="flex-1 py-2.5 rounded-lg border border-slate-700 bg-[#0B1220] hover:bg-slate-800 text-slate-300 font-semibold text-xs transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => confirmResetDemoAccount()}
            className="flex-1 py-2.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs transition-colors shadow-md shadow-amber-600/20 flex items-center justify-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Confirm Reset ($1,000)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
