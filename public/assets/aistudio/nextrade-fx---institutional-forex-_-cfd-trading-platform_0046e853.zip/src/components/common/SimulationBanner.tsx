import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShieldAlert, ArrowRight, X } from 'lucide-react';

export const SimulationBanner: React.FC = () => {
  const [dismissed, setDismissed] = useState(false);
  const location = useLocation();

  if (dismissed) return null;

  return (
    <div className="bg-[#111827] border-b border-slate-800 text-slate-300 text-xs px-4 py-2 z-40 relative">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="font-semibold text-amber-400 tracking-wide uppercase text-[11px]">
            DEMO & SIMULATED ENVIRONMENT
          </span>
          <span className="text-slate-500 hidden sm:inline">|</span>
          <span className="text-slate-400 hidden md:inline">
            Prototype UI strictly for demonstration. Fictional accounts, simulated prices, zero real funds.
          </span>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-[11px] font-medium">
            <span className="text-slate-500 hidden lg:inline">Quick Switch:</span>
            <Link
              to="/"
              className={`px-2 py-0.5 rounded transition-colors ${
                location.pathname === '/' || !location.pathname.startsWith('/trader') && !location.pathname.startsWith('/admin')
                  ? 'bg-blue-600/20 text-blue-400 font-semibold border border-blue-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Public Portal
            </Link>
            <Link
              to="/trader/terminal"
              className={`px-2 py-0.5 rounded transition-colors ${
                location.pathname.startsWith('/trader')
                  ? 'bg-blue-600/20 text-blue-400 font-semibold border border-blue-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Trader Terminal
            </Link>
            <Link
              to="/admin"
              className={`px-2 py-0.5 rounded transition-colors ${
                location.pathname.startsWith('/admin')
                  ? 'bg-blue-600/20 text-blue-400 font-semibold border border-blue-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Admin Back-Office
            </Link>
          </div>

          <button
            onClick={() => setDismissed(true)}
            className="text-slate-500 hover:text-slate-300 transition-colors p-0.5 ml-2"
            title="Dismiss notice"
            aria-label="Dismiss banner"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
