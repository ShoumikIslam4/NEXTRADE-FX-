import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { TrendingUp, Menu, X, ChevronDown } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

export const PublicNavbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [marketsDropdown, setMarketsDropdown] = useState(false);
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B1220]/95 backdrop-blur-md border-b border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-6 py-4">
        {/* Zone 1: Single Brand Wordmark Element */}
        <Link to="/" className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 group">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:bg-blue-500 transition-colors">
            <TrendingUp className="w-4 h-4 stroke-[2.5]" />
          </div>
          <span className="font-extrabold tracking-wider">NEXTRADE<span className="text-blue-500">FX</span></span>
        </Link>

        {/* Zone 2: 4-5 concise single-line nav links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
          {/* Markets with hover dropdown */}
          <div
            onMouseEnter={() => setMarketsDropdown(true)}
            onMouseLeave={() => setMarketsDropdown(false)}
            className="relative py-2 flex items-center"
          >
            <Link
              to="/markets"
              className={`flex items-center gap-1 hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                isActive('/markets') || location.pathname.startsWith('/markets') ? 'text-blue-400 font-semibold' : ''
              }`}
            >
              <span>Markets</span>
              <ChevronDown className={`w-3.5 h-3.5 opacity-70 transition-transform ${marketsDropdown ? 'rotate-180' : ''}`} />
            </Link>

            {marketsDropdown && (
              <div className="absolute top-full left-0 w-48 bg-[#151F30] border border-slate-800 rounded-lg shadow-2xl py-2 z-50 flex flex-col">
                <Link
                  to="/markets"
                  onClick={() => setMarketsDropdown(false)}
                  className="px-4 py-2 text-xs text-slate-200 hover:bg-slate-800/80 hover:text-white"
                >
                  All Markets Overview
                </Link>
                <Link
                  to="/markets/forex"
                  onClick={() => setMarketsDropdown(false)}
                  className="px-4 py-2 text-xs text-slate-200 hover:bg-slate-800/80 hover:text-white"
                >
                  Forex Majors & Minors
                </Link>
                <Link
                  to="/markets/commodities"
                  onClick={() => setMarketsDropdown(false)}
                  className="px-4 py-2 text-xs text-slate-200 hover:bg-slate-800/80 hover:text-white"
                >
                  Precious Metals & Oil
                </Link>
                <Link
                  to="/markets/indices"
                  onClick={() => setMarketsDropdown(false)}
                  className="px-4 py-2 text-xs text-slate-200 hover:bg-slate-800/80 hover:text-white"
                >
                  Global Stock Indices
                </Link>
              </div>
            )}
          </div>

          <Link
            to="/trading"
            className={`py-2 hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              isActive('/trading') ? 'text-blue-400 font-semibold' : ''
            }`}
          >
            Trading
          </Link>

          <Link
            to="/account-types"
            className={`py-2 hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              isActive('/account-types') ? 'text-blue-400 font-semibold' : ''
            }`}
          >
            Account Types
          </Link>

          <Link
            to="/education"
            className={`py-2 hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              isActive('/education') ? 'text-blue-400 font-semibold' : ''
            }`}
          >
            Education
          </Link>

          <Link
            to="/analysis"
            className={`py-2 hover:text-white transition-colors whitespace-nowrap shrink-0 ${
              isActive('/analysis') ? 'text-blue-400 font-semibold' : ''
            }`}
          >
            Analysis & News
          </Link>
        </nav>

        {/* Zone 3: 1 Primary Action Area */}
        <div className="flex items-center gap-3 shrink-0">
          <Link
            to="/login"
            className="hidden sm:inline-flex text-xs font-semibold text-slate-300 hover:text-white px-3 py-2 transition-colors whitespace-nowrap"
          >
            Client Login
          </Link>

          <Link
            to="/trader/terminal"
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm shadow-blue-500/20 whitespace-nowrap shrink-0"
          >
            Open Demo Terminal
          </Link>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-400 hover:text-white transition-colors"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-800 bg-[#0B1220] px-6 py-4 flex flex-col gap-3">
          <Link
            to="/"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            Home
          </Link>
          <Link
            to="/markets"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            Markets (Forex, Metals, Indices)
          </Link>
          <Link
            to="/trading"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            Trading Platforms & Conditions
          </Link>
          <Link
            to="/account-types"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            Account Types & Spreads
          </Link>
          <Link
            to="/economic-calendar"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            Economic Calendar
          </Link>
          <Link
            to="/analysis"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            Market Analysis & Signals
          </Link>
          <Link
            to="/education"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            Education Center
          </Link>
          <Link
            to="/faq"
            onClick={() => setMobileMenuOpen(false)}
            className="text-sm font-medium text-slate-300 hover:text-white py-1"
          >
            FAQ & Support
          </Link>
          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
            <Link
              to="/trader/terminal"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full text-center py-2.5 text-xs font-semibold text-white bg-blue-600 rounded-lg"
            >
              Launch Demo Terminal
            </Link>
            <Link
              to="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full text-center py-2 text-xs font-semibold text-slate-300 bg-[#151F30] border border-slate-700 rounded-lg"
            >
              Admin Back-Office
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
