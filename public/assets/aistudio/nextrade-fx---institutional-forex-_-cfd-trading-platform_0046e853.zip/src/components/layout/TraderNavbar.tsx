import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTrading } from '../../contexts/TradingContext';
import { useTheme } from '../../contexts/ThemeContext';
import { 
  Bell, Sun, Moon, ChevronDown, PlusCircle, 
  ShieldAlert, RefreshCw, User, LogOut, ArrowRight 
} from 'lucide-react';

export const TraderNavbar: React.FC = () => {
  const { activeAccount, accounts, switchAccount, totalFloatingProfit, depositDemoFunds, setResetModalOpen } = useTrading();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [quickDepositModal, setQuickDepositModal] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  // Derive route title
  const path = location.pathname;
  let pageTitle = 'Trader Overview';
  if (path.includes('terminal')) pageTitle = 'Institutional Trading Terminal';
  else if (path.includes('accounts')) pageTitle = 'Trading Accounts';
  else if (path.includes('positions')) pageTitle = 'Open Positions';
  else if (path.includes('pending')) pageTitle = 'Pending Orders';
  else if (path.includes('history')) pageTitle = 'Trade History';
  else if (path.includes('watchlist')) pageTitle = 'Watchlist & Quotes';
  else if (path.includes('analysis')) pageTitle = 'Market Analysis';
  else if (path.includes('signals')) pageTitle = 'Trading Signals';
  else if (path.includes('calendar')) pageTitle = 'Economic Calendar';
  else if (path.includes('wallet')) pageTitle = 'Demo Wallet';
  else if (path.includes('deposit')) pageTitle = 'Deposit Demo Funds';
  else if (path.includes('withdrawal')) pageTitle = 'Withdraw Demo Funds';
  else if (path.includes('transactions')) pageTitle = 'Financial Ledger';
  else if (path.includes('kyc')) pageTitle = 'Verification / KYC';
  else if (path.includes('notifications')) pageTitle = 'System Notifications';
  else if (path.includes('reports')) pageTitle = 'Performance Reports';
  else if (path.includes('tickets')) pageTitle = 'Support Tickets';
  else if (path.includes('profile')) pageTitle = 'Trader Profile';
  else if (path.includes('settings')) pageTitle = 'Account Settings';
  else if (path.includes('security')) pageTitle = 'Security & 2FA';

  return (
    <>
      <header className="h-14 bg-[#111827] border-b border-slate-800 flex items-center justify-between px-4 z-20 gap-3">
        {/* Left: Page Title & Breadcrumb */}
        <div className="flex items-center gap-2 min-w-0">
          <div className="text-xs font-semibold text-slate-400 hidden sm:inline">Trader Portal /</div>
          <h1 className="text-sm font-bold text-white truncate">{pageTitle}</h1>
        </div>

        {/* Center: Live Financial KPI Strip */}
        <div className="hidden lg:flex items-center gap-6 text-xs tabular-nums">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Balance (DEMO):</span>
            <span className="font-semibold text-white">${activeAccount.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Equity:</span>
            <span className="font-semibold text-white">${activeAccount.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Floating P/L:</span>
            <span className={`font-semibold ${totalFloatingProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {totalFloatingProfit >= 0 ? '+' : ''}${totalFloatingProfit.toFixed(2)}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400">Free Margin:</span>
            <span className="font-semibold text-slate-300">${activeAccount.freeMargin.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
          </div>
        </div>

        {/* Right: Account Switcher & Actions */}
        <div className="flex items-center gap-2.5">
          {/* Quick Deposit Demo Button */}
          <button
            onClick={() => setQuickDepositModal(true)}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 rounded transition-colors whitespace-nowrap"
            title="Add simulated funds to demo balance"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Add Funds</span>
          </button>

          {/* Account Dropdown */}
          <div className="relative">
            <button
              onClick={() => setAccountMenuOpen(!accountMenuOpen)}
              className="flex items-center gap-2 px-2.5 py-1 text-xs bg-[#151F30] border border-slate-700 hover:border-slate-600 rounded text-slate-200 transition-colors"
            >
              <div className={`w-2 h-2 rounded-full ${activeAccount.mode === 'DEMO' ? 'bg-blue-400' : 'bg-amber-400'}`} />
              <div className="text-left font-mono flex items-center gap-1.5">
                <span className={`text-[10px] px-1 py-0.2 rounded font-bold ${
                  activeAccount.mode === 'DEMO' ? 'bg-blue-500/20 text-blue-400' : 'bg-amber-500/20 text-amber-400'
                }`}>
                  {activeAccount.mode}
                </span>
                <span className="font-bold">{activeAccount.accountNumber}</span>
              </div>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {accountMenuOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-72 bg-[#151F30] border border-slate-700 rounded-lg shadow-2xl p-2 z-50 space-y-2">
                {/* Demo Accounts Section */}
                <div>
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-2 py-1 flex items-center justify-between">
                    <span>Demo Accounts</span>
                    <span className="text-blue-400 font-mono">$1,000 Rule</span>
                  </div>
                  {accounts.filter(a => a.mode === 'DEMO').map(acc => (
                    <button
                      key={acc.id}
                      onClick={() => {
                        switchAccount(acc.id);
                        setAccountMenuOpen(false);
                      }}
                      className={`w-full text-left p-2 rounded text-xs transition-colors flex items-center justify-between ${
                        acc.id === activeAccount.id ? 'bg-blue-600/20 text-blue-400 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div>
                        <div className="font-mono flex items-center gap-1.5">
                          <span>{acc.accountNumber}</span>
                          {acc.id === activeAccount.id && <span className="text-[9px] px-1 rounded bg-blue-500/20 text-blue-400">ACTIVE</span>}
                        </div>
                        <div className="text-[11px] text-slate-400">{acc.type} · {acc.leverage}</div>
                      </div>
                      <div className="text-right font-mono text-[11px] font-bold text-white">
                        ${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </div>
                    </button>
                  ))}
                </div>

                {/* Live Account Section */}
                <div className="pt-1 border-t border-slate-800">
                  <div className="text-[10px] font-semibold text-amber-400 uppercase tracking-wider px-2 py-1 flex items-center justify-between">
                    <span>Live Account Console</span>
                    <span className="text-amber-400 font-mono">KYC Pending</span>
                  </div>
                  {accounts.filter(a => a.mode === 'LIVE').map(acc => (
                    <button
                      key={acc.id}
                      onClick={() => {
                        switchAccount(acc.id);
                        setAccountMenuOpen(false);
                      }}
                      className={`w-full text-left p-2 rounded text-xs transition-colors flex items-center justify-between ${
                        acc.id === activeAccount.id ? 'bg-amber-600/20 text-amber-400 font-semibold' : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div>
                        <div className="font-mono flex items-center gap-1.5">
                          <span>{acc.accountNumber}</span>
                          <span className="text-[9px] px-1 rounded bg-amber-500/20 text-amber-400">{acc.status}</span>
                        </div>
                        <div className="text-[11px] text-slate-400">{acc.type} · 1:100</div>
                      </div>
                      <div className="text-right text-[10px] text-amber-400 font-semibold">
                        Awaiting Broker
                      </div>
                    </button>
                  ))}
                </div>

                <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between px-2">
                  <button
                    onClick={() => {
                      setResetModalOpen(true);
                      setAccountMenuOpen(false);
                    }}
                    className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Reset Demo ($1,000)
                  </button>
                  <Link
                    to="/trader/accounts"
                    onClick={() => setAccountMenuOpen(false)}
                    className="text-[11px] text-blue-400 hover:underline font-semibold"
                  >
                    Manage All
                  </Link>
                </div>
              </div>
            )}
          </div>

          {/* Notifications bell */}
          <div className="relative">
            <button
              onClick={() => setNotificationsOpen(!notificationsOpen)}
              className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors relative"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-blue-500" />
            </button>

            {notificationsOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-72 bg-[#151F30] border border-slate-700 rounded-lg shadow-2xl p-3 z-50 text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 mb-2">
                  <span className="font-semibold text-white">Notifications</span>
                  <Link to="/trader/notifications" onClick={() => setNotificationsOpen(false)} className="text-[11px] text-blue-400 hover:underline">
                    View All
                  </Link>
                </div>
                <div className="space-y-2">
                  <div className="p-2 rounded bg-[#0B1220]/60 border border-slate-800">
                    <div className="font-semibold text-slate-200">Simulated Tick Stream Active</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Real-time simulated volatility is running on EUR/USD, XAU/USD, and GBP/USD.</div>
                  </div>
                  <div className="p-2 rounded bg-[#0B1220]/60 border border-slate-800">
                    <div className="font-semibold text-slate-200">Daily Economic Preview</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Core PCE release at 13:30 GMT today. Expected volatility in USD crosses.</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
            title={theme === 'dark' ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* User profile avatar */}
          <div className="relative">
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="flex items-center gap-1.5 p-1 rounded hover:bg-slate-800 transition-colors"
            >
              <div className="w-7 h-7 rounded-full bg-blue-700 text-white font-bold text-xs flex items-center justify-center border border-blue-500/40">
                JD
              </div>
            </button>

            {userMenuOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-52 bg-[#151F30] border border-slate-700 rounded-lg shadow-2xl p-2 z-50 text-xs">
                <div className="px-2 py-1.5 border-b border-slate-800 mb-1">
                  <div className="font-semibold text-white">John Doe (Trader)</div>
                  <div className="text-[11px] text-slate-400">demo.trader@nextrade.io</div>
                </div>
                <Link
                  to="/trader/profile"
                  onClick={() => setUserMenuOpen(false)}
                  className="block px-2 py-1.5 rounded hover:bg-slate-800 text-slate-200"
                >
                  My Profile
                </Link>
                <Link
                  to="/trader/settings"
                  onClick={() => setUserMenuOpen(false)}
                  className="block px-2 py-1.5 rounded hover:bg-slate-800 text-slate-200"
                >
                  Account Settings
                </Link>
                <Link
                  to="/admin"
                  onClick={() => setUserMenuOpen(false)}
                  className="block px-2 py-1.5 rounded hover:bg-slate-800 text-amber-400 font-semibold"
                >
                  Switch to Admin Back-Office
                </Link>
                <div className="border-t border-slate-800 mt-1 pt-1">
                  <Link
                    to="/"
                    onClick={() => setUserMenuOpen(false)}
                    className="block px-2 py-1.5 rounded hover:bg-slate-800 text-rose-400"
                  >
                    Exit to Public Site
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Quick Deposit Demo Modal */}
      {quickDepositModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#151F30] border border-slate-700 rounded-xl max-w-md w-full p-5 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-1">Deposit Demo Funds</h3>
            <p className="text-xs text-slate-400 mb-4">
              Add simulated funds to your demo account #{activeAccount.accountNumber} with zero risk.
            </p>

            <div className="grid grid-cols-2 gap-2.5 mb-5">
              {[5000, 10000, 25000, 50000].map(amount => (
                <button
                  key={amount}
                  onClick={() => {
                    depositDemoFunds(amount);
                    setQuickDepositModal(false);
                  }}
                  className="p-3 rounded-lg bg-[#0B1220] border border-slate-700 hover:border-blue-500 hover:bg-blue-600/10 text-left transition-colors"
                >
                  <div className="text-xs text-slate-400">Quick Deposit</div>
                  <div className="text-sm font-bold text-white font-mono">+${amount.toLocaleString()}</div>
                </button>
              ))}
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setQuickDepositModal(false)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
