import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { CurrencyPair } from '../types/market';
import { 
  Position, PendingOrder, TradeHistoryItem, TradingAccount, 
  WalletTransaction, OrderSide, OrderType, LiveApplication, LiveApplicationStatus, AccountMode 
} from '../types/trading';
import { INITIAL_CURRENCY_PAIRS } from '../data/mockMarketData';
import { useToast } from './ToastContext';
import { 
  calculateMarginRequired, calculateFloatingPnL, validateOrderParams, 
  checkPendingTrigger, checkPositionExitTrigger 
} from '../services/tradingEngine';

interface PlaceOrderParams {
  symbol: string;
  side: OrderSide;
  lots: number;
  stopLoss?: number;
  takeProfit?: number;
}

interface PlacePendingParams {
  symbol: string;
  type: OrderType;
  side: OrderSide;
  targetPrice: number;
  lots: number;
  stopLoss?: number;
  takeProfit?: number;
}

interface TradingContextType {
  pairs: CurrencyPair[];
  selectedPair: CurrencyPair;
  setSelectedPairSymbol: (symbol: string) => void;
  positions: Position[];
  allPositions: Position[];
  pendingOrders: PendingOrder[];
  history: TradeHistoryItem[];
  accounts: TradingAccount[];
  activeAccount: TradingAccount;
  transactions: WalletTransaction[];
  watchlist: string[];
  liveApplication: LiveApplication;
  toggleWatchlist: (symbol: string) => void;
  openMarketOrder: (params: PlaceOrderParams) => boolean;
  placePendingOrder: (params: PlacePendingParams) => boolean;
  closePosition: (id: string) => void;
  cancelPendingOrder: (id: string) => void;
  depositDemoFunds: (amount: number, method?: string) => void;
  withdrawDemoFunds: (amount: number, method?: string) => boolean;
  switchAccount: (accountId: string) => void;
  createDemoAccount: (params: { type: string; leverage: string }) => TradingAccount;
  submitLiveApplication: (data: Partial<LiveApplication>) => void;
  updateLiveApplicationStatus: (status: LiveApplicationStatus, notes?: string) => void;
  confirmResetDemoAccount: (accountId?: string) => void;
  resetModalOpen: boolean;
  setResetModalOpen: (open: boolean) => void;
  totalFloatingProfit: number;
  todayProfit: number;
}

const TradingContext = createContext<TradingContextType | undefined>(undefined);

// Initial Accounts: Strictly $1,000 starting balance for Demo
const SEED_ACCOUNTS: TradingAccount[] = [
  {
    id: 'acc-demo-1',
    accountNumber: 'NX-DEMO-809214',
    mode: 'DEMO',
    type: 'Raw ECN Demo',
    server: 'NEXTRADE-Demo-01',
    leverage: '1:500',
    currency: 'USD',
    initialBalance: 1000.0,
    balance: 1000.0,
    equity: 1000.0,
    margin: 0.0,
    freeMargin: 1000.0,
    marginLevel: 0.0,
    floatingProfit: 0.0,
    isPrimary: true,
    status: 'ACTIVE',
    createdAt: '2026-11-10'
  },
  {
    id: 'acc-demo-2',
    accountNumber: 'NX-DEMO-610482',
    mode: 'DEMO',
    type: 'Standard Demo',
    server: 'NEXTRADE-Demo-01',
    leverage: '1:200',
    currency: 'USD',
    initialBalance: 1000.0,
    balance: 1000.0,
    equity: 1000.0,
    margin: 0.0,
    freeMargin: 1000.0,
    marginLevel: 0.0,
    floatingProfit: 0.0,
    isPrimary: false,
    status: 'ACTIVE',
    createdAt: '2026-11-11'
  },
  {
    id: 'acc-live-1',
    accountNumber: 'NX-LIVE-10492',
    mode: 'LIVE',
    type: 'Institutional ECN Live',
    server: 'NEXTRADE-Live-Prime',
    leverage: '1:100',
    currency: 'USD',
    initialBalance: 0.0,
    balance: 0.0,
    equity: 0.0,
    margin: 0.0,
    freeMargin: 0.0,
    marginLevel: 0.0,
    floatingProfit: 0.0,
    isPrimary: false,
    status: 'PENDING_VERIFICATION',
    createdAt: '2026-11-11'
  }
];

const SEED_LIVE_APP: LiveApplication = {
  id: 'APP-LIVE-10492',
  fullName: 'Alexander Vance',
  email: 'alexander.vance@institutional-trader.com',
  phone: '+1 (555) 382-9104',
  country: 'United Kingdom',
  employmentStatus: 'Full-time Private Capital / Trader',
  annualIncome: '$100,000 - $250,000',
  tradingExperience: '3-5 Years (Forex & CFDs)',
  riskTolerance: 'Moderate',
  idType: 'Passport',
  idNumber: 'GB-P88291410',
  proofOfAddress: 'Tier 1 Bank Statement (London)',
  status: 'UNDER_REVIEW',
  submittedAt: '2026-11-11 11:30:00',
  brokerConnectivity: 'UNAVAILABLE_PENDING_BROKER_INTEGRATION'
};

const SEED_POSITIONS: Position[] = [
  {
    id: 'pos-101',
    accountId: 'acc-demo-1',
    symbol: 'EUR/USD',
    side: 'BUY',
    lots: 0.1,
    openPrice: 1.08240,
    currentPrice: 1.08437,
    stopLoss: 1.07900,
    takeProfit: 1.09100,
    floatingProfit: 19.70,
    pips: 19.7,
    openTime: '2026-11-11 14:15:20',
    marginUsed: 21.68,
    swap: -0.12,
    commission: 0.35
  },
  {
    id: 'pos-102',
    accountId: 'acc-demo-1',
    symbol: 'XAU/USD',
    side: 'BUY',
    lots: 0.05,
    openPrice: 2736.80,
    currentPrice: 2742.60,
    stopLoss: 2720.00,
    takeProfit: 2765.00,
    floatingProfit: 29.00,
    pips: 58.0,
    openTime: '2026-11-11 15:40:05',
    marginUsed: 27.42,
    swap: -0.34,
    commission: 0.25
  }
];

const SEED_PENDING: PendingOrder[] = [
  {
    id: 'pnd-201',
    accountId: 'acc-demo-1',
    symbol: 'USD/JPY',
    type: 'LIMIT',
    side: 'BUY',
    lots: 0.1,
    targetPrice: 152.900,
    currentPrice: 153.420,
    stopLoss: 152.200,
    takeProfit: 154.500,
    placedTime: '2026-11-11 13:20:00',
    status: 'PENDING'
  }
];

const SEED_HISTORY: TradeHistoryItem[] = [
  {
    id: 'his-301',
    accountId: 'acc-demo-1',
    symbol: 'EUR/USD',
    side: 'BUY',
    lots: 0.2,
    openPrice: 1.07920,
    closePrice: 1.08380,
    openTime: '2026-11-10 09:12:00',
    closeTime: '2026-11-10 18:40:22',
    pips: 46.0,
    profit: 92.0,
    reason: 'Take Profit Hit'
  },
  {
    id: 'his-302',
    accountId: 'acc-demo-1',
    symbol: 'USD/JPY',
    side: 'SELL',
    lots: 0.1,
    openPrice: 154.120,
    closePrice: 153.380,
    openTime: '2026-11-09 11:25:00',
    closeTime: '2026-11-09 15:10:45',
    pips: 74.0,
    profit: 48.24,
    reason: 'Manual Close'
  }
];

const SEED_TRANSACTIONS: WalletTransaction[] = [
  {
    id: 'TXN-001',
    date: '2026-11-10 08:00:00',
    type: 'DEPOSIT',
    amount: 1000.0,
    currency: 'USD',
    status: 'COMPLETED',
    method: 'Simulated Demo Initial Capital',
    reference: 'SIM-INIT-1000',
    accountNumber: 'NX-DEMO-809214'
  }
];

// LocalStorage Persistence Helper
function loadStorage<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    console.warn(`LocalStorage read error for ${key}:`, e);
    return fallback;
  }
}

function saveStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn(`LocalStorage write error for ${key}:`, e);
  }
}

export const TradingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { addToast } = useToast();

  const [pairs, setPairs] = useState<CurrencyPair[]>(INITIAL_CURRENCY_PAIRS);
  const [selectedPairSymbol, setSelectedPairSymbol] = useState<string>('EUR/USD');

  // Persistent States
  const [accounts, setAccounts] = useState<TradingAccount[]>(() =>
    loadStorage('nextrade_accounts_v3', SEED_ACCOUNTS)
  );

  const [activeAccountId, setActiveAccountId] = useState<string>(() =>
    loadStorage('nextrade_active_acc_id_v3', 'acc-demo-1')
  );

  const [allPositions, setAllPositions] = useState<Position[]>(() =>
    loadStorage('nextrade_positions_v3', SEED_POSITIONS)
  );

  const [allPendingOrders, setAllPendingOrders] = useState<PendingOrder[]>(() =>
    loadStorage('nextrade_pending_v3', SEED_PENDING)
  );

  const [allHistory, setAllHistory] = useState<TradeHistoryItem[]>(() =>
    loadStorage('nextrade_history_v3', SEED_HISTORY)
  );

  const [transactions, setTransactions] = useState<WalletTransaction[]>(() =>
    loadStorage('nextrade_transactions_v3', SEED_TRANSACTIONS)
  );

  const [liveApplication, setLiveApplication] = useState<LiveApplication>(() =>
    loadStorage('nextrade_live_app_v3', SEED_LIVE_APP)
  );

  const [watchlist, setWatchlist] = useState<string[]>(['EUR/USD', 'GBP/USD', 'USD/JPY', 'XAU/USD', 'US30.cash']);
  const [resetModalOpen, setResetModalOpen] = useState(false);

  // Sync to LocalStorage
  useEffect(() => {
    saveStorage('nextrade_accounts_v3', accounts);
  }, [accounts]);

  useEffect(() => {
    saveStorage('nextrade_active_acc_id_v3', activeAccountId);
  }, [activeAccountId]);

  useEffect(() => {
    saveStorage('nextrade_positions_v3', allPositions);
  }, [allPositions]);

  useEffect(() => {
    saveStorage('nextrade_pending_v3', allPendingOrders);
  }, [allPendingOrders]);

  useEffect(() => {
    saveStorage('nextrade_history_v3', allHistory);
  }, [allHistory]);

  useEffect(() => {
    saveStorage('nextrade_transactions_v3', transactions);
  }, [transactions]);

  useEffect(() => {
    saveStorage('nextrade_live_app_v3', liveApplication);
  }, [liveApplication]);

  const accountsRef = useRef(accounts);
  accountsRef.current = accounts;

  // Positions scoped strictly to active account (Demo vs Live data isolation)
  const positions = useMemo(() => {
    return allPositions.filter(p => p.accountId === activeAccountId);
  }, [allPositions, activeAccountId]);

  // Pending orders scoped strictly to active account
  const pendingOrders = useMemo(() => {
    return allPendingOrders.filter(o => o.accountId === activeAccountId);
  }, [allPendingOrders, activeAccountId]);

  // History scoped strictly to active account
  const history = useMemo(() => {
    return allHistory.filter(h => h.accountId === activeAccountId);
  }, [allHistory, activeAccountId]);

  const selectedPair = useMemo(() => {
    return pairs.find(p => p.symbol === selectedPairSymbol) || pairs[0];
  }, [pairs, selectedPairSymbol]);

  const totalFloatingProfit = useMemo(() => {
    return Number(positions.reduce((acc, p) => acc + (p.floatingProfit || 0), 0).toFixed(2));
  }, [positions]);

  const activeUsedMargin = useMemo(() => {
    return Number(positions.reduce((acc, p) => acc + (p.marginUsed || 0), 0).toFixed(2));
  }, [positions]);

  // Active account derived with live computed equity, margin, freeMargin, marginLevel, floatingProfit
  const activeAccount: TradingAccount = useMemo(() => {
    const raw = accounts.find(a => a.id === activeAccountId) || accounts[0];
    const newEquity = Number((raw.balance + totalFloatingProfit).toFixed(2));
    const freeMargin = Number((newEquity - activeUsedMargin).toFixed(2));
    const marginLevel = activeUsedMargin > 0 ? Number(((newEquity / activeUsedMargin) * 100).toFixed(1)) : 0;
    return {
      ...raw,
      equity: newEquity,
      margin: activeUsedMargin,
      freeMargin,
      marginLevel,
      floatingProfit: totalFloatingProfit
    };
  }, [accounts, activeAccountId, totalFloatingProfit, activeUsedMargin]);

  // Computed accounts list providing live metrics for all accounts
  const computedAccounts: TradingAccount[] = useMemo(() => {
    return accounts.map(raw => {
      if (raw.id === activeAccountId) return activeAccount;
      const accPositions = allPositions.filter(p => p.accountId === raw.id);
      const m = Number(accPositions.reduce((acc, p) => acc + (p.marginUsed || 0), 0).toFixed(2));
      const fp = Number(accPositions.reduce((acc, p) => acc + (p.floatingProfit || 0), 0).toFixed(2));
      const eq = Number((raw.balance + fp).toFixed(2));
      const free = Number((eq - m).toFixed(2));
      const lvl = m > 0 ? Number(((eq / m) * 100).toFixed(1)) : 0;
      return {
        ...raw,
        equity: eq,
        margin: m,
        freeMargin: free,
        marginLevel: lvl,
        floatingProfit: fp
      };
    });
  }, [accounts, activeAccountId, activeAccount, allPositions]);

  const todayProfit = useMemo(() => {
    const closedToday = history
      .filter(h => h.closeTime.startsWith('2026-11-11'))
      .reduce((acc, h) => acc + h.profit, 0);
    return Number((closedToday + totalFloatingProfit).toFixed(2));
  }, [history, totalFloatingProfit]);

  // Tick Engine + Auto SL/TP + Auto Pending Order Triggering
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Update pair ticks
      setPairs(currentPairs => {
        return currentPairs.map(pair => {
          if (Math.random() > 0.45) return pair;

          const tickDirection = Math.random() > 0.49 ? 1 : -1;
          const minPip = Math.pow(10, -pair.pipPrecision);
          const pipJitter = (Math.floor(Math.random() * 2) + 1) * minPip * tickDirection;

          let newBid = Number((pair.bid + pipJitter).toFixed(pair.pipPrecision));
          let newAsk = Number((newBid + (pair.spread / pair.pipMultiplier)).toFixed(pair.pipPrecision));
          let newHigh = Math.max(pair.high24h, newAsk);
          let newLow = Math.min(pair.low24h, newBid);

          return {
            ...pair,
            bid: newBid,
            ask: newAsk,
            high24h: newHigh,
            low24h: newLow
          };
        });
      });
    }, 1200);

    return () => clearInterval(interval);
  }, []);

  // Price updates reaction: P/L calculation, SL/TP auto-exit, and Pending Order activation
  // Strictly decoupled from accounts state to prevent infinite update depth loops
  useEffect(() => {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 19);
    let newlyActivatedPositions: Position[] = [];

    // 1. Check Pending Orders for Activation
    setAllPendingOrders(prevPending => {
      const remainingPending: PendingOrder[] = [];
      const activated: Position[] = [];

      for (const order of prevPending) {
        const pair = pairs.find(p => p.symbol === order.symbol);
        if (!pair || order.status !== 'PENDING') {
          remainingPending.push(order);
          continue;
        }

        const isTriggered = checkPendingTrigger(order, pair);
        if (isTriggered) {
          const acc = accountsRef.current.find(a => a.id === order.accountId) || accountsRef.current[0];
          const execPrice = order.side === 'BUY' ? pair.ask : pair.bid;
          const marginReq = calculateMarginRequired(pair, order.lots, execPrice, acc.leverage);

          activated.push({
            id: `pos-${Math.floor(1000 + Math.random() * 9000)}`,
            accountId: order.accountId,
            symbol: order.symbol,
            side: order.side,
            lots: order.lots,
            openPrice: order.targetPrice,
            currentPrice: execPrice,
            stopLoss: order.stopLoss,
            takeProfit: order.takeProfit,
            floatingProfit: 0.0,
            pips: 0.0,
            openTime: nowStr,
            marginUsed: marginReq,
            swap: 0.0,
            commission: Number((order.lots * 3.5).toFixed(2))
          });

          addToast({
            type: 'info',
            title: 'Pending Order Activated (DEMO)',
            message: `${order.type} ${order.side} ${order.lots} Lots ${order.symbol} triggered @ ${order.targetPrice}`
          });
        } else {
          remainingPending.push(order);
        }
      }

      newlyActivatedPositions = activated;
      return remainingPending;
    });

    // 2. Check Positions for P/L updates and SL/TP hits
    setAllPositions(prevPositions => {
      const basePositions = newlyActivatedPositions.length > 0
        ? [...newlyActivatedPositions, ...prevPositions]
        : prevPositions;

      const remaining: Position[] = [];
      const exitedHistory: TradeHistoryItem[] = [];
      let balanceDelta = 0;
      let targetAccId = '';

      for (const pos of basePositions) {
        const pair = pairs.find(p => p.symbol === pos.symbol);
        if (!pair) {
          remaining.push(pos);
          continue;
        }

        // Instrument-specific P/L calculation
        const { currentPrice, pips, floatingProfit } = calculateFloatingPnL(
          pos, pair, pair.bid, pair.ask
        );

        // Check SL/TP exit
        const exitCheck = checkPositionExitTrigger(pos, pair);
        if (exitCheck.hit && exitCheck.reason) {
          targetAccId = pos.accountId || 'acc-demo-1';
          const realized = floatingProfit - pos.commission;
          balanceDelta += realized;

          exitedHistory.push({
            id: `his-${Math.floor(1000 + Math.random() * 9000)}`,
            accountId: pos.accountId,
            symbol: pos.symbol,
            side: pos.side,
            lots: pos.lots,
            openPrice: pos.openPrice,
            closePrice: exitCheck.exitPrice || currentPrice,
            openTime: pos.openTime,
            closeTime: nowStr,
            pips,
            profit: Number(realized.toFixed(2)),
            reason: exitCheck.reason
          });

          addToast({
            type: exitCheck.reason === 'Take Profit Hit' ? 'success' : 'warning',
            title: `${exitCheck.reason} (DEMO)`,
            message: `Closed ${pos.side} ${pos.lots} lots ${pos.symbol} @ ${currentPrice} (${realized >= 0 ? '+' : ''}$${realized.toFixed(2)})`
          });
        } else {
          remaining.push({
            ...pos,
            currentPrice,
            pips,
            floatingProfit
          });
        }
      }

      // If any positions closed via SL/TP, record history and update account balance
      if (exitedHistory.length > 0) {
        setAllHistory(h => [...exitedHistory, ...h]);
        if (targetAccId) {
          setAccounts(accs =>
            accs.map(a => {
              if (a.id === targetAccId) {
                const newBal = Number((a.balance + balanceDelta).toFixed(2));
                return { ...a, balance: newBal };
              }
              return a;
            })
          );
        }
      }

      return remaining;
    });
  }, [pairs, addToast]);

  // Watchlist Toggle
  const toggleWatchlist = useCallback((symbol: string) => {
    setWatchlist(prev => {
      if (prev.includes(symbol)) {
        addToast({ type: 'info', title: 'Watchlist', message: `Removed ${symbol} from watchlist.` });
        return prev.filter(s => s !== symbol);
      } else {
        addToast({ type: 'success', title: 'Watchlist', message: `Added ${symbol} to watchlist.` });
        return [...prev, symbol];
      }
    });
  }, [addToast]);

  // Open Market Order
  const openMarketOrder = useCallback(({ symbol, side, lots, stopLoss, takeProfit }: PlaceOrderParams): boolean => {
    const pair = pairs.find(p => p.symbol === symbol);
    if (!pair) {
      addToast({ type: 'error', title: 'Order Failed', message: `Symbol ${symbol} not recognized.` });
      return false;
    }

    const validation = validateOrderParams(
      symbol, side, 'MARKET', lots, pair, activeAccount, undefined, stopLoss, takeProfit
    );

    if (!validation.valid) {
      addToast({ type: 'error', title: 'Order Rejected', message: validation.error || 'Invalid order parameters.' });
      return false;
    }

    const price = side === 'BUY' ? pair.ask : pair.bid;
    const marginReq = validation.marginReq || calculateMarginRequired(pair, lots, price, activeAccount.leverage);
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    const newPos: Position = {
      id: `pos-${Math.floor(1000 + Math.random() * 9000)}`,
      accountId: activeAccountId,
      symbol,
      side,
      lots,
      openPrice: price,
      currentPrice: price,
      stopLoss,
      takeProfit,
      floatingProfit: 0.0,
      pips: 0.0,
      openTime: now,
      marginUsed: marginReq,
      swap: 0.0,
      commission: Number((lots * 3.5).toFixed(2))
    };

    setAllPositions(prev => [newPos, ...prev]);
    addToast({
      type: 'success',
      title: 'Order Executed (DEMO)',
      message: `${side} ${lots} Lots ${symbol} @ ${price.toFixed(pair.pipPrecision)}`
    });
    return true;
  }, [pairs, activeAccount, activeAccountId, addToast]);

  // Place Pending Order
  const placePendingOrder = useCallback(({ symbol, type, side, targetPrice, lots, stopLoss, takeProfit }: PlacePendingParams): boolean => {
    const pair = pairs.find(p => p.symbol === symbol);
    if (!pair) return false;

    const validation = validateOrderParams(
      symbol, side, type, lots, pair, activeAccount, targetPrice, stopLoss, takeProfit
    );

    if (!validation.valid) {
      addToast({ type: 'error', title: 'Pending Order Rejected', message: validation.error || 'Invalid order parameters.' });
      return false;
    }

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const order: PendingOrder = {
      id: `pnd-${Math.floor(1000 + Math.random() * 9000)}`,
      accountId: activeAccountId,
      symbol,
      type,
      side,
      lots,
      targetPrice,
      currentPrice: side === 'BUY' ? pair.ask : pair.bid,
      stopLoss,
      takeProfit,
      placedTime: now,
      status: 'PENDING'
    };

    setAllPendingOrders(prev => [order, ...prev]);
    addToast({
      type: 'success',
      title: 'Pending Order Placed (DEMO)',
      message: `${type} ${side} ${lots} Lots ${symbol} @ ${targetPrice.toFixed(pair.pipPrecision)}`
    });
    return true;
  }, [pairs, activeAccount, activeAccountId, addToast]);

  // Close Position Manually
  const closePosition = useCallback((id: string) => {
    const pos = allPositions.find(p => p.id === id);
    if (!pos) return;

    const closePrice = pos.currentPrice;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    const historyRecord: TradeHistoryItem = {
      id: `his-${Math.floor(1000 + Math.random() * 9000)}`,
      accountId: pos.accountId,
      symbol: pos.symbol,
      side: pos.side,
      lots: pos.lots,
      openPrice: pos.openPrice,
      closePrice,
      openTime: pos.openTime,
      closeTime: now,
      pips: pos.pips,
      profit: pos.floatingProfit,
      reason: 'Manual Close'
    };

    // Update account balance
    setAccounts(prev =>
      prev.map(acc => {
        if (acc.id === pos.accountId) {
          const newBal = Number((acc.balance + pos.floatingProfit - pos.commission).toFixed(2));
          return {
            ...acc,
            balance: newBal
          };
        }
        return acc;
      })
    );

    setAllHistory(prev => [historyRecord, ...prev]);
    setAllPositions(prev => prev.filter(p => p.id !== id));

    addToast({
      type: pos.floatingProfit >= 0 ? 'success' : 'warning',
      title: 'Position Closed (DEMO)',
      message: `Closed ${pos.side} ${pos.lots} lots ${pos.symbol} for ${pos.floatingProfit >= 0 ? '+' : ''}$${pos.floatingProfit.toFixed(2)} USD`
    });
  }, [allPositions, addToast]);

  // Cancel Pending Order
  const cancelPendingOrder = useCallback((id: string) => {
    setAllPendingOrders(prev => prev.filter(o => o.id !== id));
    addToast({
      type: 'info',
      title: 'Order Cancelled',
      message: 'Pending order successfully cancelled.'
    });
  }, [addToast]);

  // Demo Funds Deposit - Enforce $1,000 Starting Rule & Cap
  const depositDemoFunds = useCallback((amount: number, method: string = 'Simulated Practice Credit') => {
    if (activeAccount.mode === 'LIVE') {
      addToast({
        type: 'error',
        title: 'Action Unavailable',
        message: 'Real-money deposits are disabled pending regulatory broker integration and live approval.'
      });
      return;
    }

    if (activeAccount.balance >= 1000) {
      addToast({
        type: 'warning',
        title: 'Demo Balance Rule',
        message: 'Demo accounts operate under a strict $1,000 practice rule. Your balance is already at or above $1,000 USD. Use Reset Demo Account if you want to restart.'
      });
      return;
    }

    // Top up only up to $1,000
    const allowableAmount = Math.min(amount, 1000 - activeAccount.balance);
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

    setAccounts(prev =>
      prev.map(acc => {
        if (acc.id === activeAccountId) {
          const newBal = acc.balance + allowableAmount;
          return {
            ...acc,
            balance: newBal,
            equity: acc.equity + allowableAmount,
            freeMargin: acc.freeMargin + allowableAmount
          };
        }
        return acc;
      })
    );

    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      date: now,
      type: 'DEPOSIT',
      amount: allowableAmount,
      currency: 'USD',
      status: 'COMPLETED',
      method,
      reference: `SIM-DEP-${Math.floor(100000 + Math.random() * 900000)}`,
      accountNumber: activeAccount.accountNumber
    };

    setTransactions(prev => [newTxn, ...prev]);
    addToast({
      type: 'success',
      title: 'Demo Balance Topped Up',
      message: `+$${allowableAmount.toFixed(2)} added to restore demo balance up to the $1,000 practice limit.`
    });
  }, [activeAccount, activeAccountId, addToast]);

  // Demo Funds Withdrawal
  const withdrawDemoFunds = useCallback((amount: number, method: string = 'Simulated Wire'): boolean => {
    if (activeAccount.mode === 'LIVE') {
      addToast({
        type: 'error',
        title: 'Action Unavailable',
        message: 'Real-money withdrawals are disabled until live broker connectivity is verified.'
      });
      return false;
    }

    if (amount > activeAccount.freeMargin) {
      addToast({
        type: 'error',
        title: 'Withdrawal Failed',
        message: 'Withdrawal amount exceeds available demo free margin.'
      });
      return false;
    }

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    setAccounts(prev =>
      prev.map(acc => {
        if (acc.id === activeAccountId) {
          return {
            ...acc,
            balance: acc.balance - amount,
            equity: acc.equity - amount,
            freeMargin: acc.freeMargin - amount
          };
        }
        return acc;
      })
    );

    const newTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      date: now,
      type: 'WITHDRAWAL',
      amount,
      currency: 'USD',
      status: 'COMPLETED',
      method,
      reference: `SIM-WTH-${Math.floor(100000 + Math.random() * 900000)}`,
      accountNumber: activeAccount.accountNumber
    };

    setTransactions(prev => [newTxn, ...prev]);
    addToast({
      type: 'success',
      title: 'Demo Withdrawal Processed',
      message: `-$${amount.toLocaleString()} deducted from demo balance.`
    });
    return true;
  }, [activeAccount, activeAccountId, addToast]);

  // Switch Active Account
  const switchAccount = useCallback((accountId: string) => {
    const acc = accounts.find(a => a.id === accountId);
    if (!acc) return;

    setActiveAccountId(accountId);
    addToast({
      type: acc.mode === 'LIVE' ? 'warning' : 'info',
      title: `Switched to ${acc.mode} Account`,
      message: `${acc.accountNumber} (${acc.type}) is now active.${acc.mode === 'LIVE' ? ' (Live execution safely disabled)' : ''}`
    });
  }, [accounts, addToast]);

  // Create New Demo Account (Strictly $1,000 initial balance)
  const createDemoAccount = useCallback(({ type, leverage }: { type: string; leverage: string }): TradingAccount => {
    const randNum = Math.floor(100000 + Math.random() * 900000);
    const newAcc: TradingAccount = {
      id: `acc-demo-${randNum}`,
      accountNumber: `NX-DEMO-${randNum}`,
      mode: 'DEMO',
      type: type || 'Raw ECN Demo',
      server: 'NEXTRADE-Demo-01',
      leverage: leverage || '1:500',
      currency: 'USD',
      initialBalance: 1000.0,
      balance: 1000.0,
      equity: 1000.0,
      margin: 0.0,
      freeMargin: 1000.0,
      marginLevel: 0.0,
      floatingProfit: 0.0,
      isPrimary: false,
      status: 'ACTIVE',
      createdAt: new Date().toISOString().split('T')[0]
    };

    setAccounts(prev => [...prev, newAcc]);
    setActiveAccountId(newAcc.id);
    addToast({
      type: 'success',
      title: 'Demo Account Created',
      message: `Account #${newAcc.accountNumber} created with exactly $1,000 USD virtual balance.`
    });
    return newAcc;
  }, [addToast]);

  // Submit Live Account Application
  const submitLiveApplication = useCallback((data: Partial<LiveApplication>) => {
    const newApp: LiveApplication = {
      ...liveApplication,
      ...data,
      id: `APP-LIVE-${Math.floor(10000 + Math.random() * 90000)}`,
      status: 'UNDER_REVIEW',
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      brokerConnectivity: 'UNAVAILABLE_PENDING_BROKER_INTEGRATION'
    };

    setLiveApplication(newApp);

    // Update or ensure a live account exists with PENDING_VERIFICATION
    setAccounts(prev => {
      const existingLive = prev.find(a => a.mode === 'LIVE');
      if (existingLive) {
        return prev.map(a => a.id === existingLive.id ? { ...a, status: 'PENDING_VERIFICATION' } : a);
      } else {
        const randNum = Math.floor(10000 + Math.random() * 90000);
        const liveAcc: TradingAccount = {
          id: `acc-live-${randNum}`,
          accountNumber: `NX-LIVE-${randNum}`,
          mode: 'LIVE',
          type: 'Institutional ECN Live',
          server: 'NEXTRADE-Live-Prime',
          leverage: '1:100',
          currency: 'USD',
          initialBalance: 0.0,
          balance: 0.0,
          equity: 0.0,
          margin: 0.0,
          freeMargin: 0.0,
          marginLevel: 0.0,
          floatingProfit: 0.0,
          isPrimary: false,
          status: 'PENDING_VERIFICATION',
          createdAt: new Date().toISOString().split('T')[0]
        };
        return [...prev, liveAcc];
      }
    });

    addToast({
      type: 'info',
      title: 'Live Application Submitted',
      message: 'KYC documents and financial profile submitted for institutional compliance review.'
    });
  }, [liveApplication, addToast]);

  // Update Live Application Status (Admin action)
  const updateLiveApplicationStatus = useCallback((status: LiveApplicationStatus, notes?: string) => {
    setLiveApplication(prev => ({
      ...prev,
      status,
      reviewedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      rejectionReason: notes
    }));

    setAccounts(prev =>
      prev.map(a => {
        if (a.mode === 'LIVE') {
          return {
            ...a,
            status: status === 'APPROVED_PENDING_BROKER' ? 'ACTIVE' : 'PENDING_VERIFICATION'
          };
        }
        return a;
      })
    );

    addToast({
      type: 'info',
      title: 'Application Status Updated',
      message: `Live application status updated to: ${status}`
    });
  }, [addToast]);

  // Reset Demo Account - Confirmation Action (Restores strictly $1,000 USD and clears demo positions)
  const confirmResetDemoAccount = useCallback((targetAccountId?: string) => {
    const accId = targetAccountId || activeAccountId;
    const target = accounts.find(a => a.id === accId);

    if (target?.mode === 'LIVE') {
      addToast({
        type: 'error',
        title: 'Action Prohibited',
        message: 'Cannot reset live accounts.'
      });
      return;
    }

    // Reset account to initial $1,000
    setAccounts(prev =>
      prev.map(acc => {
        if (acc.id === accId) {
          return {
            ...acc,
            balance: 1000.0,
            equity: 1000.0,
            margin: 0.0,
            freeMargin: 1000.0,
            marginLevel: 0.0,
            floatingProfit: 0.0
          };
        }
        return acc;
      })
    );

    // Clear positions and pending orders for this account
    setAllPositions(prev => prev.filter(p => p.accountId !== accId));
    setAllPendingOrders(prev => prev.filter(o => o.accountId !== accId));

    // Log transaction
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const resetTxn: WalletTransaction = {
      id: `TXN-${Math.floor(1000 + Math.random() * 9000)}`,
      date: now,
      type: 'INTERNAL_TRANSFER',
      amount: 1000.0,
      currency: 'USD',
      status: 'COMPLETED',
      method: 'Demo Account Reset ($1,000 USD Restored)',
      reference: `RESET-${Math.floor(100000 + Math.random() * 900000)}`,
      accountNumber: target?.accountNumber || 'NX-DEMO'
    };
    setTransactions(prev => [resetTxn, ...prev]);

    setResetModalOpen(false);
    addToast({
      type: 'success',
      title: 'Demo Account Reset Confirmed',
      message: `Account #${target?.accountNumber || accId} balance restored to $1,000.00 USD and open positions cleared.`
    });
  }, [accounts, activeAccountId, addToast]);

  return (
    <TradingContext.Provider
      value={{
        pairs,
        selectedPair,
        setSelectedPairSymbol,
        positions,
        allPositions,
        pendingOrders,
        history,
        accounts: computedAccounts,
        activeAccount,
        transactions,
        watchlist,
        liveApplication,
        toggleWatchlist,
        openMarketOrder,
        placePendingOrder,
        closePosition,
        cancelPendingOrder,
        depositDemoFunds,
        withdrawDemoFunds,
        switchAccount,
        createDemoAccount,
        submitLiveApplication,
        updateLiveApplicationStatus,
        confirmResetDemoAccount,
        resetModalOpen,
        setResetModalOpen,
        totalFloatingProfit,
        todayProfit
      }}
    >
      {children}
    </TradingContext.Provider>
  );
};

export const useTrading = () => {
  const context = useContext(TradingContext);
  if (!context) {
    throw new Error('useTrading must be used within TradingProvider');
  }
  return context;
};
