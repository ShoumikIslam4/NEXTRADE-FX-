import React, { useState } from 'react';
import { useTrading } from '../../contexts/TradingContext';
import { useToast } from '../../contexts/ToastContext';
import { 
  Activity, ListOrdered, Eye, Receipt, ArrowDownCircle, 
  ArrowUpCircle, CreditCard, Search, CheckCircle2, XCircle, AlertTriangle 
} from 'lucide-react';

export const TradingMonitorPage: React.FC = () => {
  const exposures = [
    { pair: 'EUR/USD', longLots: 42.5, shortLots: 38.0, netLots: '+4.5 Long', risk: 'LOW' },
    { pair: 'GBP/USD', longLots: 18.0, shortLots: 29.5, netLots: '-11.5 Short', risk: 'MEDIUM' },
    { pair: 'USD/JPY', longLots: 55.0, shortLots: 22.0, netLots: '+33.0 Long', risk: 'HIGH' },
    { pair: 'XAU/USD', longLots: 120.5, shortLots: 84.0, netLots: '+36.5 Long', risk: 'HIGH' },
    { pair: 'US30.cash', longLots: 14.0, shortLots: 12.0, netLots: '+2.0 Long', risk: 'LOW' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Dealing Desk & Exposure Monitor</h2>
        <p className="text-xs text-slate-400 mt-1">
          Aggregated net risk exposure across client books and simulated liquidity bridge routing.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="p-5 bg-[#111827] border border-slate-800 rounded-xl">
          <div className="text-xs text-slate-400 uppercase font-semibold">Total Long Exposure</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-2">250.0 Lots</div>
          <div className="text-[11px] text-slate-500 mt-1">~$25M Notional Value</div>
        </div>

        <div className="p-5 bg-[#111827] border border-slate-800 rounded-xl">
          <div className="text-xs text-slate-400 uppercase font-semibold">Total Short Exposure</div>
          <div className="text-2xl font-bold font-mono text-rose-400 mt-2">185.5 Lots</div>
          <div className="text-[11px] text-slate-500 mt-1">~$18.5M Notional Value</div>
        </div>

        <div className="p-5 bg-[#111827] border border-slate-800 rounded-xl">
          <div className="text-xs text-slate-400 uppercase font-semibold">Net Warehouse Skew</div>
          <div className="text-2xl font-bold font-mono text-amber-400 mt-2">+64.5 Lots Long</div>
          <div className="text-[11px] text-slate-500 mt-1">A-Book Hedged Ratio: 85%</div>
        </div>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800">
          <h3 className="text-sm font-bold text-white">Asset Class Exposure Breakdown</h3>
        </div>
        <table className="w-full text-left text-xs tabular-nums font-mono">
          <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Instrument</th>
              <th className="py-3 px-4">Client Long Volume</th>
              <th className="py-3 px-4">Client Short Volume</th>
              <th className="py-3 px-4">Net Exposure</th>
              <th className="py-3 px-4 text-right">Risk Score</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {exposures.map(exp => (
              <tr key={exp.pair} className="hover:bg-[#151F30]/60">
                <td className="py-3 px-4 font-bold text-white font-mono">{exp.pair}</td>
                <td className="py-3 px-4 text-emerald-400">{exp.longLots} Lots</td>
                <td className="py-3 px-4 text-rose-400">{exp.shortLots} Lots</td>
                <td className="py-3 px-4 font-bold text-white">{exp.netLots}</td>
                <td className="py-3 px-4 text-right">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold font-sans ${
                    exp.risk === 'LOW' ? 'bg-emerald-500/20 text-emerald-400' :
                    exp.risk === 'MEDIUM' ? 'bg-amber-500/20 text-amber-400' :
                    'bg-rose-500/20 text-rose-400'
                  }`}>
                    {exp.risk}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const OrdersManagementPage: React.FC = () => {
  const { pendingOrders, cancelPendingOrder } = useTrading();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Orders Management</h2>
        <p className="text-xs text-slate-400 mt-1">Audit and supervise all pending limit, stop, and market order triggers.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full text-left text-xs tabular-nums font-mono">
          <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Order ID</th>
              <th className="py-3 px-4">Time Placed</th>
              <th className="py-3 px-4">Symbol</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Lots</th>
              <th className="py-3 px-4">Target Price</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Admin Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {pendingOrders.map(o => (
              <tr key={o.id} className="hover:bg-[#151F30]/60">
                <td className="py-3 px-4 text-slate-400">{o.id}</td>
                <td className="py-3 px-4 text-slate-400">{o.placedTime}</td>
                <td className="py-3 px-4 font-bold text-white">{o.symbol}</td>
                <td className="py-3 px-4 text-blue-400 font-bold">{o.type} {o.side}</td>
                <td className="py-3 px-4">{o.lots} Lots</td>
                <td className="py-3 px-4 text-amber-400 font-bold">{o.targetPrice}</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{o.status}</td>
                <td className="py-3 px-4 text-right">
                  <button
                    onClick={() => cancelPendingOrder(o.id)}
                    className="px-2.5 py-1 rounded bg-rose-600/20 text-rose-400 border border-rose-500/30 hover:bg-rose-600 hover:text-white transition-colors text-xs font-sans font-semibold"
                  >
                    Force Cancel
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const AdminPositionsPage: React.FC = () => {
  const { positions, closePosition } = useTrading();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Dealing Desk Open Positions</h2>
        <p className="text-xs text-slate-400 mt-1">Live streaming position monitor across all simulated client accounts.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full text-left text-xs tabular-nums font-mono">
          <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Position Ticket</th>
              <th className="py-3 px-4">Open Time</th>
              <th className="py-3 px-4">Instrument</th>
              <th className="py-3 px-4">Side</th>
              <th className="py-3 px-4">Lots</th>
              <th className="py-3 px-4">Open Price</th>
              <th className="py-3 px-4">Current Price</th>
              <th className="py-3 px-4">Floating P/L</th>
              <th className="py-3 px-4 text-right">Dealing Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {positions.map(p => (
              <tr key={p.id} className="hover:bg-[#151F30]/60">
                <td className="py-3 px-4 text-slate-400">{p.id}</td>
                <td className="py-3 px-4 text-slate-400">{p.openTime}</td>
                <td className="py-3 px-4 font-bold text-white">{p.symbol}</td>
                <td className="py-3 px-4 font-bold">
                  <span className={p.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}>{p.side}</span>
                </td>
                <td className="py-3 px-4">{p.lots.toFixed(2)}</td>
                <td className="py-3 px-4">{p.openPrice}</td>
                <td className="py-3 px-4 font-bold text-white">{p.currentPrice}</td>
                <td className={`py-3 px-4 font-bold ${p.floatingProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {p.floatingProfit >= 0 ? '+' : ''}${p.floatingProfit.toFixed(2)}
                </td>
                <td className="py-3 px-4 text-right">
                  <button
                    onClick={() => closePosition(p.id)}
                    className="px-2.5 py-1 rounded bg-rose-600/20 text-rose-400 border border-rose-500/30 hover:bg-rose-600 hover:text-white transition-colors text-xs font-sans font-semibold"
                  >
                    Force Liquidate
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const AdminTransactionsPage: React.FC = () => {
  const { transactions } = useTrading();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Transaction Management (Admin)</h2>
        <p className="text-xs text-slate-400 mt-1">Master financial log of all client deposits, withdrawals, and account balances.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full text-left text-xs tabular-nums font-mono">
          <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">TX ID</th>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4">Account</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Gateway</th>
              <th className="py-3 px-4">Amount</th>
              <th className="py-3 px-4 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {transactions.map(t => (
              <tr key={t.id} className="hover:bg-[#151F30]/60">
                <td className="py-3 px-4 text-slate-400">{t.id}</td>
                <td className="py-3 px-4 text-slate-400">{t.date}</td>
                <td className="py-3 px-4 font-bold text-white">{t.accountNumber}</td>
                <td className="py-3 px-4 font-bold text-blue-400">{t.type}</td>
                <td className="py-3 px-4 font-sans text-slate-300">{t.method}</td>
                <td className={`py-3 px-4 font-bold ${t.type === 'DEPOSIT' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {t.type === 'DEPOSIT' ? '+' : '-'}${t.amount.toLocaleString()} {t.currency}
                </td>
                <td className="py-3 px-4 text-right">
                  <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-sans font-bold">
                    {t.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const AdminDepositsPage: React.FC = () => {
  const { depositDemoFunds, activeAccount, confirmResetDemoAccount } = useTrading();
  const { addToast } = useToast();

  const handleResetTo1000 = () => {
    confirmResetDemoAccount(activeAccount.id);
    addToast({ type: 'success', title: 'Demo Reset', message: `Account ${activeAccount.accountNumber} reset to exactly $1,000.00 USD.` });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">Deposit Administration</h2>
          <p className="text-xs text-slate-400 mt-1">Supervise simulated liquidity inflows and enforce the $1,000 practice baseline protocol.</p>
        </div>
        <button
          onClick={handleResetTo1000}
          className="px-3.5 py-2 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
        >
          <ArrowDownCircle className="w-3.5 h-3.5" />
          <span>Reset Active Account to $1,000 Baseline</span>
        </button>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5 text-xs text-slate-300">
        Demo practice accounts are capped at $1,000.00 USD to reflect institutional risk parameters. Live account deposits remain locked pending regulatory broker authorization.
      </div>
    </div>
  );
};

export const AdminWithdrawalsPage: React.FC = () => {
  const { addToast } = useToast();
  const [requests, setRequests] = useState([
    { id: 'WTH-881', client: 'Alexander Wright', account: 'NX-809214', amount: 15000, method: 'Bank Wire (Barclays UK)', time: '2026-11-11 11:30', status: 'PENDING' },
    { id: 'WTH-882', client: 'Sophia Chen', account: 'NX-610482', amount: 5000, method: 'DBS Singapore Fast', time: '2026-11-11 09:15', status: 'PENDING' }
  ]);

  const handleAction = (id: string, action: 'APPROVED' | 'REJECTED') => {
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status: action } : r));
    addToast({
      type: action === 'APPROVED' ? 'success' : 'warning',
      title: `Withdrawal ${action}`,
      message: `Request ${id} marked as ${action}.`
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Withdrawal Requests Queue</h2>
        <p className="text-xs text-slate-400 mt-1">Review, approve, or reject pending simulated client withdrawals.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full text-left text-xs tabular-nums font-mono">
          <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Request ID</th>
              <th className="py-3 px-4">Trader Name</th>
              <th className="py-3 px-4">Account</th>
              <th className="py-3 px-4">Amount (USD)</th>
              <th className="py-3 px-4">Destination</th>
              <th className="py-3 px-4">Requested At</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {requests.map(r => (
              <tr key={r.id} className="hover:bg-[#151F30]/60">
                <td className="py-3 px-4 text-slate-400">{r.id}</td>
                <td className="py-3 px-4 font-bold text-white font-sans">{r.client}</td>
                <td className="py-3 px-4 font-bold">{r.account}</td>
                <td className="py-3 px-4 font-bold text-rose-400">${r.amount.toLocaleString()}</td>
                <td className="py-3 px-4 font-sans text-slate-300">{r.method}</td>
                <td className="py-3 px-4 text-slate-400">{r.time}</td>
                <td className="py-3 px-4">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold font-sans ${
                    r.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400' :
                    r.status === 'PENDING' ? 'bg-amber-500/20 text-amber-400' :
                    'bg-rose-500/20 text-rose-400'
                  }`}>
                    {r.status}
                  </span>
                </td>
                <td className="py-3 px-4 text-right">
                  {r.status === 'PENDING' && (
                    <div className="flex items-center justify-end gap-1.5 font-sans">
                      <button
                        onClick={() => handleAction(r.id, 'APPROVED')}
                        className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleAction(r.id, 'REJECTED')}
                        className="px-2 py-1 rounded bg-rose-600/20 text-rose-400 hover:bg-rose-600 hover:text-white border border-rose-500/30 font-semibold text-xs"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const PaymentMethodsPage: React.FC = () => {
  const { addToast } = useToast();
  const [methods, setMethods] = useState([
    { id: 'wire', name: 'SEPA & SWIFT Wire Transfer', type: 'Bank Transfer', status: 'ACTIVE', fee: '0.00%', maxLimit: '$500,000' },
    { id: 'visa', name: 'Visa / Mastercard Acquiring', type: 'Credit Card', status: 'ACTIVE', fee: '0.00%', maxLimit: '$50,000' },
    { id: 'crypto', name: 'USDT (Tether ERC-20 / TRC-20)', type: 'Cryptocurrency', status: 'ACTIVE', fee: '0.00%', maxLimit: '$1,000,000' },
    { id: 'ach', name: 'US Fedwire / ACH Direct', type: 'Bank Transfer', status: 'ACTIVE', fee: '0.00%', maxLimit: '$250,000' },
  ]);

  const toggle = (id: string) => {
    setMethods(prev => prev.map(m => {
      if (m.id === id) {
        const next = m.status === 'ACTIVE' ? 'DISABLED' : 'ACTIVE';
        addToast({ type: 'info', title: 'Gateway Updated', message: `${m.name} is now ${next}` });
        return { ...m, status: next };
      }
      return m;
    }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Payment Methods & Gateways</h2>
        <p className="text-xs text-slate-400 mt-1">Configure processing thresholds, fee tiers, and simulated gateway availability.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full text-left text-xs tabular-nums font-mono">
          <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Gateway Name</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Fee Structure</th>
              <th className="py-3 px-4">Max Single Limit</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right font-sans">Toggle</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {methods.map(m => (
              <tr key={m.id} className="hover:bg-[#151F30]/60">
                <td className="py-3 px-4 font-bold text-white">{m.name}</td>
                <td className="py-3 px-4 text-slate-400">{m.type}</td>
                <td className="py-3 px-4 font-mono text-emerald-400 font-bold">{m.fee}</td>
                <td className="py-3 px-4 font-mono text-white">{m.maxLimit}</td>
                <td className="py-3 px-4">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                    m.status === 'ACTIVE' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {m.status}
                  </span>
                </td>
                <td className="py-3 px-4 text-right">
                  <button
                    onClick={() => toggle(m.id)}
                    className="px-2.5 py-1 rounded bg-[#151F30] border border-slate-700 text-slate-200 hover:text-white text-xs font-semibold"
                  >
                    {m.status === 'ACTIVE' ? 'Disable' : 'Enable'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
