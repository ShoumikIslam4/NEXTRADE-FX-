import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Users, Activity, FileCheck, ArrowDownCircle, ArrowUpCircle, 
  Layers, ShieldAlert, TrendingUp, BarChart3, AlertCircle, 
  ArrowRight, CheckCircle2, Clock 
} from 'lucide-react';
import { MOCK_ADMIN_USERS, MOCK_KYC_SUBMISSIONS, MOCK_AUDIT_LOGS } from '../../data/mockAdminData';

export const AdminOverviewPage: React.FC = () => {
  const kpis = [
    {
      title: 'Total Registered Users',
      value: '2,840',
      subtitle: '+48 this week',
      icon: Users,
      color: 'text-blue-400',
      border: 'border-blue-500/30'
    },
    {
      title: 'Active Traders (24h)',
      value: '1,420',
      subtitle: 'Simulating trades',
      icon: Activity,
      color: 'text-emerald-400',
      border: 'border-emerald-500/30'
    },
    {
      title: 'Active Demo Accounts',
      value: '4,190',
      subtitle: 'Standard, ECN & Pro',
      icon: Layers,
      color: 'text-white',
      border: 'border-slate-800'
    },
    {
      title: 'Total Demo Volume (24h)',
      value: '18,450 Lots',
      subtitle: '~$1.84B simulated notional',
      icon: TrendingUp,
      color: 'text-amber-400',
      border: 'border-amber-500/30'
    },
    {
      title: 'Pending KYC Submissions',
      value: '2',
      subtitle: 'Action required',
      icon: FileCheck,
      color: 'text-amber-400',
      border: 'border-amber-500/30'
    },
    {
      title: 'Pending Withdrawals',
      value: '3',
      subtitle: 'Sample review queue',
      icon: ArrowUpCircle,
      color: 'text-rose-400',
      border: 'border-rose-500/30'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-[#151F30] border border-slate-800 rounded-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
              SUPER ADMIN CONSOLE
            </span>
            <span className="text-xs text-slate-400">· Dealing Desk, Risk & Compliance</span>
          </div>
          <h2 className="text-xl font-extrabold text-white">Platform Back-Office Overview</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time telemetry of simulated liquidity, trader volume, risk exposure, and verification queues.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/admin/kyc"
            className="px-3.5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Review KYC (2)</span>
          </Link>
          <Link
            to="/admin/monitor"
            className="px-3.5 py-2 text-xs font-bold text-slate-200 bg-[#0B1220] hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <span>Dealing Monitor</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* KPI Cards (6 metrics) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <div key={idx} className={`p-4 bg-[#111827] border ${kpi.border} rounded-lg flex flex-col justify-between`}>
              <div className="flex items-center justify-between text-slate-400 text-[11px] font-semibold uppercase tracking-wider">
                <span>{kpi.title}</span>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className={`text-xl font-bold font-mono my-2 ${kpi.color}`}>
                {kpi.value}
              </div>
              <div className="text-[11px] text-slate-500 truncate">
                {kpi.subtitle}
              </div>
            </div>
          );
        })}
      </div>

      {/* Middle Grid: Pending KYC Queue & Dealing Desk Snapshot */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Pending KYC Submissions (6 cols) */}
        <div className="lg:col-span-6 bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-amber-400" />
              <h3 className="text-sm font-bold text-white">Pending KYC Compliance Submissions</h3>
            </div>
            <Link to="/admin/kyc" className="text-xs text-blue-400 hover:underline">
              View All
            </Link>
          </div>

          <div className="divide-y divide-slate-800/60 flex-1">
            {MOCK_KYC_SUBMISSIONS.slice(0, 3).map(kyc => (
              <div key={kyc.id} className="p-4 flex items-center justify-between hover:bg-[#151F30]/50 transition-colors">
                <div>
                  <div className="text-xs font-bold text-white">{kyc.userName}</div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">{kyc.userEmail} · {kyc.documentType}</div>
                  <div className="text-[10px] text-slate-500 mt-1">{kyc.notes}</div>
                </div>

                <div className="text-right">
                  <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                    kyc.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400' :
                    kyc.status === 'PENDING' ? 'bg-amber-500/20 text-amber-400' :
                    'bg-rose-500/20 text-rose-400'
                  }`}>
                    {kyc.status}
                  </span>
                  <div className="text-[10px] text-slate-500 mt-1">{kyc.submittedAt}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Admin Audit Logs (6 cols) */}
        <div className="lg:col-span-6 bg-[#111827] border border-slate-800 rounded-xl overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-400" />
              <h3 className="text-sm font-bold text-white">System Audit & Dealing Logs</h3>
            </div>
            <Link to="/admin/audit-logs" className="text-xs text-blue-400 hover:underline">
              Full Audit Trail
            </Link>
          </div>

          <div className="divide-y divide-slate-800/60 flex-1 font-mono text-xs">
            {MOCK_AUDIT_LOGS.map(log => (
              <div key={log.id} className="p-3.5 hover:bg-[#151F30]/50 transition-colors">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-amber-400 text-[11px]">{log.action}</span>
                  <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                </div>
                <div className="text-slate-300 font-sans text-xs">{log.details}</div>
                <div className="text-[10px] text-slate-500 mt-1">
                  Operator: {log.staffUser} · IP: {log.ipAddress}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Users Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Recent Trader Accounts</h3>
          <Link to="/admin/users" className="text-xs text-blue-400 hover:underline">
            Manage All Users ({MOCK_ADMIN_USERS.length})
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs tabular-nums font-mono">
            <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4">User ID</th>
                <th className="py-2.5 px-4">Name</th>
                <th className="py-2.5 px-4">Email</th>
                <th className="py-2.5 px-4">Country</th>
                <th className="py-2.5 px-4">KYC</th>
                <th className="py-2.5 px-4">Demo Balance</th>
                <th className="py-2.5 px-4">Volume Traded</th>
                <th className="py-2.5 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {MOCK_ADMIN_USERS.map(u => (
                <tr key={u.id} className="hover:bg-[#151F30]/60">
                  <td className="py-2.5 px-4 text-slate-400">{u.id}</td>
                  <td className="py-2.5 px-4 font-bold text-white font-sans">{u.name}</td>
                  <td className="py-2.5 px-4 text-slate-300">{u.email}</td>
                  <td className="py-2.5 px-4 font-sans text-slate-400">{u.country}</td>
                  <td className="py-2.5 px-4">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      u.kycStatus === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400' :
                      u.kycStatus === 'PENDING' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-rose-500/20 text-rose-400'
                    }`}>
                      {u.kycStatus}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 font-bold text-white">${u.totalBalanceDemo.toLocaleString()}</td>
                  <td className="py-2.5 px-4 text-slate-300">{u.totalVolumeLots} Lots</td>
                  <td className="py-2.5 px-4 text-right">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      u.status === 'ACTIVE' ? 'text-emerald-400 bg-emerald-500/10' : 'text-rose-400 bg-rose-500/10'
                    }`}>
                      {u.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
