import React, { useState } from 'react';
import { useToast } from '../../contexts/ToastContext';
import { MOCK_ADMIN_USERS, MOCK_KYC_SUBMISSIONS } from '../../data/mockAdminData';
import { AdminUser, AdminKycSubmission } from '../../types/admin';
import { 
  Users, Search, Filter, CheckCircle2, XCircle, 
  Eye, ShieldAlert, FileCheck, Layers, AlertCircle, Edit, Download 
} from 'lucide-react';

export const UserManagementPage: React.FC = () => {
  const { addToast } = useToast();
  const [users, setUsers] = useState<AdminUser[]>(MOCK_ADMIN_USERS);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);

  const filtered = users.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(search.toLowerCase()) ||
                          u.email.toLowerCase().includes(search.toLowerCase()) ||
                          u.id.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || u.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const toggleUserStatus = (id: string) => {
    setUsers(prev => prev.map(u => {
      if (u.id === id) {
        const nextStatus = u.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
        addToast({
          type: nextStatus === 'ACTIVE' ? 'success' : 'warning',
          title: 'User Status Updated',
          message: `${u.name} marked as ${nextStatus}`
        });
        return { ...u, status: nextStatus };
      }
      return u;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">Trader User Management</h2>
          <p className="text-xs text-slate-400 mt-1">
            Search, inspect credentials, and manage trading permissions across all registered client accounts.
          </p>
        </div>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        {/* Filters */}
        <div className="p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 max-w-sm w-full">
            <Search className="w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by name, email, or user ID..."
              className="w-full bg-[#151F30] border border-slate-700 rounded px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Status:</span>
            {['ALL', 'ACTIVE', 'SUSPENDED', 'FLAGGED'].map(st => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded font-medium transition-colors ${
                  statusFilter === st ? 'bg-amber-600 text-white font-bold' : 'text-slate-400 hover:text-white bg-[#151F30]'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Users Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs tabular-nums font-mono">
            <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Client ID</th>
                <th className="py-3 px-4">Full Name</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Country</th>
                <th className="py-3 px-4">KYC</th>
                <th className="py-3 px-4">Total Demo Balance</th>
                <th className="py-3 px-4">Volume</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map(u => (
                <tr key={u.id} className="hover:bg-[#151F30]/60">
                  <td className="py-3 px-4 text-slate-400">{u.id}</td>
                  <td className="py-3 px-4 font-bold text-white font-sans">{u.name}</td>
                  <td className="py-3 px-4 text-slate-300">{u.email}</td>
                  <td className="py-3 px-4 font-sans text-slate-400">{u.country}</td>
                  <td className="py-3 px-4">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      u.kycStatus === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400' :
                      u.kycStatus === 'PENDING' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-rose-500/20 text-rose-400'
                    }`}>
                      {u.kycStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-bold text-white">${u.totalBalanceDemo.toLocaleString()}</td>
                  <td className="py-3 px-4 text-slate-300">{u.totalVolumeLots} Lots</td>
                  <td className="py-3 px-4">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      u.status === 'ACTIVE' ? 'text-emerald-400 bg-emerald-500/10' : 'text-rose-400 bg-rose-500/10'
                    }`}>
                      {u.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setSelectedUser(u)}
                        className="px-2 py-1 rounded bg-[#151F30] text-slate-200 hover:text-white border border-slate-700 text-xs font-sans"
                      >
                        Inspect
                      </button>
                      <button
                        onClick={() => toggleUserStatus(u.id)}
                        className={`px-2 py-1 rounded text-xs font-sans font-semibold ${
                          u.status === 'ACTIVE' ? 'bg-rose-500/15 text-rose-400 hover:bg-rose-500/25' : 'bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25'
                        }`}
                      >
                        {u.status === 'ACTIVE' ? 'Suspend' : 'Activate'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Inspect User Details Modal */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#151F30] border border-slate-700 rounded-xl max-w-lg w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div>
                <h3 className="text-base font-bold text-white">{selectedUser.name}</h3>
                <div className="text-xs text-slate-400 font-mono">{selectedUser.id} · {selectedUser.email}</div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                {selectedUser.status}
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3 p-3 bg-[#0B1220] rounded-lg">
                <div>
                  <span className="text-slate-500 block text-[11px]">Phone</span>
                  <span className="text-white font-mono">{selectedUser.phone}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Registration IP</span>
                  <span className="text-white font-mono">{selectedUser.ipAddress}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Registered Date</span>
                  <span className="text-white font-mono">{selectedUser.registeredDate}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Demo Accounts</span>
                  <span className="text-white font-mono">{selectedUser.totalDemoAccounts} active</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-5">
              <button
                onClick={() => setSelectedUser(null)}
                className="px-4 py-2 rounded bg-slate-800 text-slate-200 hover:text-white text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import { useTrading } from '../../contexts/TradingContext';

export const KycManagementPage: React.FC = () => {
  const { addToast } = useToast();
  const { liveApplication, updateLiveApplicationStatus } = useTrading();
  const [submissions, setSubmissions] = useState<AdminKycSubmission[]>(MOCK_KYC_SUBMISSIONS);

  const updateStatus = (id: string, newStatus: 'APPROVED' | 'REJECTED') => {
    setSubmissions(prev => prev.map(s => {
      if (s.id === id) {
        addToast({
          type: newStatus === 'APPROVED' ? 'success' : 'warning',
          title: `KYC ${newStatus}`,
          message: `Submission ${id} for ${s.userName} marked as ${newStatus}`
        });
        return { ...s, status: newStatus };
      }
      return s;
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">KYC & Live Account Applications Queue</h2>
          <p className="text-xs text-slate-400 mt-1">Review applicant identity documentation, financial profiles, and broker clearance status.</p>
        </div>
      </div>

      {/* Primary Live Application from Current Session */}
      <div className="p-5 bg-[#151F30] border border-amber-500/40 rounded-xl space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">{liveApplication.fullName}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold uppercase border border-amber-500/30">
                  LIVE APPLICATION · {liveApplication.status.replace('_', ' ')}
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono">{liveApplication.id} · {liveApplication.email} · {liveApplication.country}</div>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400">{liveApplication.submittedAt}</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-[#0B1220] rounded-lg text-xs font-mono">
          <div>
            <span className="text-[10px] text-slate-500 block font-sans">GOVERNMENT ID</span>
            <span className="font-bold text-white">{liveApplication.idType} ({liveApplication.idNumber || 'Verified'})</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block font-sans">PROOF OF ADDRESS</span>
            <span className="font-bold text-slate-200">{liveApplication.proofOfAddress}</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block font-sans">EXPERIENCE & RISK</span>
            <span className="text-white">{liveApplication.tradingExperience} ({liveApplication.riskTolerance})</span>
          </div>
          <div>
            <span className="text-[10px] text-slate-500 block font-sans">BROKER BRIDGE</span>
            <span className="text-amber-400 font-bold font-sans">Awaiting Regulatory Bridge</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <button
            onClick={() => updateLiveApplicationStatus('APPROVED_PENDING_BROKER', 'Identity verified. Awaiting authorized broker connectivity.')}
            className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Approve Application (Pending Broker Bridge)</span>
          </button>
          <button
            onClick={() => updateLiveApplicationStatus('DOCS_REQUESTED', 'Please provide an updated proof of address dated within 30 days.')}
            className="px-3.5 py-1.5 rounded-lg bg-[#0B1220] border border-amber-500/30 text-amber-400 hover:bg-amber-500/10 font-bold text-xs transition-colors"
          >
            Request Additional Docs
          </button>
          <button
            onClick={() => updateLiveApplicationStatus('REJECTED', 'Jurisdictional restrictions or document mismatch.')}
            className="px-3.5 py-1.5 rounded-lg bg-rose-600/20 text-rose-400 hover:bg-rose-600 hover:text-white border border-rose-500/30 font-bold text-xs transition-colors"
          >
            Reject Application
          </button>
        </div>
      </div>

      {/* Historical KYC Queue */}
      <h3 className="text-sm font-bold text-white pt-2">Simulated Trader Verification Queue</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {submissions.map(sub => (
          <div key={sub.id} className="p-5 bg-[#111827] border border-slate-800 rounded-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-base font-bold text-white">{sub.userName}</div>
                <div className="text-xs text-slate-400 font-mono">{sub.userEmail}</div>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                sub.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400' :
                sub.status === 'PENDING' ? 'bg-amber-500/20 text-amber-400' :
                'bg-rose-500/20 text-rose-400'
              }`}>
                {sub.status}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 bg-[#0B1220] border border-slate-800/80 rounded-lg text-xs font-mono">
              <div>
                <span className="text-[10px] text-slate-500 block font-sans">DOCUMENT TYPE</span>
                <span className="font-bold text-slate-200">{sub.documentType}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block font-sans">DOCUMENT ID</span>
                <span className="font-bold text-white">{sub.documentNumber}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block font-sans">SUBMISSION TIME</span>
                <span className="text-slate-400">{sub.submittedAt}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-500 block font-sans">RISK SCORE</span>
                <span className={`font-bold ${sub.riskScore === 'LOW' ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {sub.riskScore} RISK
                </span>
              </div>
            </div>

            {sub.notes && (
              <div className="text-xs text-slate-400 bg-[#151F30] p-2.5 rounded border border-slate-800">
                <span className="font-semibold text-slate-300">Auditor Notes: </span>
                {sub.notes}
              </div>
            )}

            {sub.status === 'PENDING' && (
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() => updateStatus(sub.id, 'APPROVED')}
                  className="flex-1 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Approve KYC</span>
                </button>
                <button
                  onClick={() => updateStatus(sub.id, 'REJECTED')}
                  className="flex-1 py-2 rounded bg-rose-600/20 text-rose-400 hover:bg-rose-600 hover:text-white border border-rose-500/30 font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>Reject Submission</span>
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export const TradingAccountsAdminPage: React.FC = () => {
  const { accounts } = useTrading();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Trading Accounts & Risk Monitor</h2>
        <p className="text-xs text-slate-400 mt-1">
          Distinguish active Demo Practice accounts ($1,000 starting rule) from Live Onboarding consoles.
        </p>
      </div>

      {/* Active Accounts Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 bg-[#151F30] border-b border-slate-800 flex items-center justify-between">
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            Client Accounts Ledger ({accounts.length} Total Accounts)
          </span>
          <span className="text-[11px] text-blue-400 font-mono">Demo Rule: $1,000 Starting Virtual Capital</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs tabular-nums font-mono min-w-[700px]">
            <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Account Number</th>
                <th className="py-3 px-4">Mode</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Server</th>
                <th className="py-3 px-4">Leverage</th>
                <th className="py-3 px-4">Balance</th>
                <th className="py-3 px-4">Equity</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Execution</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {accounts.map(a => (
                <tr key={a.id} className="hover:bg-[#151F30]/60">
                  <td className="py-3 px-4 font-bold text-white">{a.accountNumber}</td>
                  <td className="py-3 px-4">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold font-sans ${
                      a.mode === 'DEMO' ? 'bg-blue-500/20 text-blue-400' : 'bg-amber-500/20 text-amber-400'
                    }`}>
                      {a.mode}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-sans text-slate-300 font-semibold">{a.type}</td>
                  <td className="py-3 px-4 text-slate-400">{a.server}</td>
                  <td className="py-3 px-4">{a.leverage}</td>
                  <td className="py-3 px-4 font-bold text-white">${a.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                  <td className="py-3 px-4 font-bold text-white">${a.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                  <td className="py-3 px-4 font-sans">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      a.status === 'ACTIVE' ? 'text-emerald-400 bg-emerald-500/10' : 'text-amber-400 bg-amber-500/10'
                    }`}>
                      {a.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-sans">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                      a.mode === 'DEMO' ? 'text-blue-400 bg-blue-500/10' : 'text-amber-400 bg-amber-500/10'
                    }`}>
                      {a.mode === 'DEMO' ? 'Simulated Feed' : 'Broker Pending'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
