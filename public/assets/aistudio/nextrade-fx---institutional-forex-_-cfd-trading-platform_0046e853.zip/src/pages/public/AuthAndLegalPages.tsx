import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '../../contexts/ToastContext';
import { useTrading } from '../../contexts/TradingContext';
import { LiveOnboardingModal } from '../../components/account/LiveOnboardingModal';
import { 
  TrendingUp, Lock, Mail, User, ShieldAlert, 
  ArrowRight, CheckCircle2, ShieldCheck, DollarSign, 
  Sparkles, RefreshCw, Layers, Shield
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { addToast } = useToast();
  const { accounts, switchAccount } = useTrading();
  const navigate = useNavigate();
  const [email, setEmail] = useState('demo.trader@nextrade.io');
  const [password, setPassword] = useState('••••••••••••');
  const [selectedAccType, setSelectedAccType] = useState<'DEMO' | 'LIVE'>('DEMO');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedAccType === 'DEMO') {
      const demoAcc = accounts.find(a => a.mode === 'DEMO') || accounts[0];
      switchAccount(demoAcc.id);
      addToast({
        type: 'success',
        title: 'Demo Session Initialized',
        message: `Welcome back to NEXTRADE FX. Active account: #${demoAcc.accountNumber} ($1,000 Virtual Capital).`
      });
      navigate('/trader/terminal');
    } else {
      const liveAcc = accounts.find(a => a.mode === 'LIVE');
      if (liveAcc) switchAccount(liveAcc.id);
      addToast({
        type: 'info',
        title: 'Live Account Portal',
        message: 'Signed into Live Account Console. Status: Awaiting Broker Authorization & Live Integration.'
      });
      navigate('/trader/accounts');
    }
  };

  const handleAdminQuickLogin = () => {
    addToast({
      type: 'info',
      title: 'Admin Session',
      message: 'Signed in as Dominic Sterling (Super Administrator).'
    });
    navigate('/admin/overview');
  };

  return (
    <div className="max-w-md mx-auto px-6 py-14 space-y-6">
      <div className="text-center space-y-2">
        <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white mx-auto shadow-lg shadow-blue-500/20">
          <TrendingUp className="w-5 h-5 stroke-[2.5]" />
        </div>
        <h1 className="text-2xl font-extrabold text-white">Client Portal Sign In</h1>
        <p className="text-xs text-slate-400">
          Access your simulated trading accounts and terminal workspace.
        </p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-5">
        {/* Account Mode Selector */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#0B1220] rounded-lg border border-slate-800 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setSelectedAccType('DEMO')}
            className={`py-2 rounded-md transition-colors flex items-center justify-center gap-1.5 ${
              selectedAccType === 'DEMO'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Demo Trading</span>
            <span className="text-[10px] px-1 bg-white/20 rounded font-mono">$1,000</span>
          </button>
          <button
            type="button"
            onClick={() => setSelectedAccType('LIVE')}
            className={`py-2 rounded-md transition-colors flex items-center justify-center gap-1.5 ${
              selectedAccType === 'LIVE'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>Live Account</span>
            <span className="text-[10px] px-1 bg-white/20 rounded">KYC</span>
          </button>
        </div>

        <form onSubmit={handleLogin} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full bg-[#0B1220] border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-slate-300 font-semibold">Password</label>
              <Link to="/forgot-password" className="text-blue-400 hover:underline">Forgot Password?</Link>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full bg-[#0B1220] border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className={`w-full py-2.5 text-white font-bold rounded-lg transition-colors shadow-md ${
              selectedAccType === 'DEMO'
                ? 'bg-blue-600 hover:bg-blue-500 shadow-blue-500/20'
                : 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/20'
            }`}
          >
            Sign In to {selectedAccType === 'DEMO' ? 'Demo Terminal ($1,000 Virtual)' : 'Live Account Console'}
          </button>
        </form>

        <div className="pt-4 border-t border-slate-800/80 space-y-3">
          <div className="text-[11px] text-slate-400 text-center">Demo Quick-Access Shortcuts:</div>
          <button
            type="button"
            onClick={handleAdminQuickLogin}
            className="w-full py-2 bg-[#151F30] hover:bg-slate-800 text-amber-400 border border-amber-500/30 rounded-lg text-xs font-bold transition-colors"
          >
            Direct Switch: Admin Back-Office Console
          </button>
        </div>
      </div>

      <div className="text-center text-xs text-slate-400">
        Don't have an account?{' '}
        <Link to="/register" className="text-blue-400 font-semibold hover:underline">
          Open Demo ($1,000) or Apply for Live
        </Link>
      </div>
    </div>
  );
};

export const RegisterPage: React.FC = () => {
  const { addToast } = useToast();
  const { createDemoAccount } = useTrading();
  const navigate = useNavigate();

  const [selectedOption, setSelectedOption] = useState<'DEMO' | 'LIVE'>('DEMO');
  const [demoName, setDemoName] = useState('Alex Wright');
  const [demoEmail, setDemoEmail] = useState('alex.wright@nextrade.io');
  const [demoLeverage, setDemoLeverage] = useState('1:500');
  const [demoType, setDemoType] = useState('Raw ECN Demo');

  const [liveModalOpen, setLiveModalOpen] = useState(false);

  const handleDemoRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const newAcc = createDemoAccount({
      type: demoType,
      leverage: demoLeverage
    });

    addToast({
      type: 'success',
      title: 'Demo Account Created',
      message: `Account #${newAcc.accountNumber} created with exactly $1,000 USD virtual balance.`
    });
    navigate('/trader/terminal');
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12 space-y-8">
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <h1 className="text-3xl font-extrabold text-white">Choose Your Trading Account</h1>
        <p className="text-xs text-slate-400 leading-relaxed">
          Select between simulated risk-free practice with a strict $1,000 virtual balance or complete live institutional onboarding with identity verification.
        </p>
      </div>

      {/* Two Account Options: Option A (Demo) vs Option B (Live) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch">
        {/* OPTION A: DEMO TRADING */}
        <div className={`p-6 rounded-2xl border transition-all flex flex-col justify-between ${
          selectedOption === 'DEMO' 
            ? 'bg-[#151F30] border-blue-500 shadow-xl shadow-blue-500/10 ring-1 ring-blue-500' 
            : 'bg-[#111827] border-slate-800 hover:border-slate-700'
        }`}>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30 uppercase tracking-wider">
                Option A · Practice
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                $1,000 USD Virtual Balance
              </span>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white">Demo Account</h2>
              <p className="text-xs text-slate-400 mt-1">
                Zero capital risk. Full simulated terminal features with instrument-specific Forex, Metals, and Indices execution.
              </p>
            </div>

            {/* Demo Rules Checklist */}
            <ul className="space-y-2 text-xs text-slate-300 pt-2 border-t border-slate-800">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Starts with exactly <strong>$1,000 USD</strong> virtual capital</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Simulated real-time tick feeds & execution</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Strict $1,000 balance cap to enforce discipline</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>One-click Reset with confirmation if balance depletes</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Never connects to real brokers or real funds</span>
              </li>
            </ul>

            {/* Demo Registration Fields */}
            <form onSubmit={handleDemoRegister} className="pt-3 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Trader Name</label>
                  <input
                    type="text"
                    required
                    value={demoName}
                    onChange={e => setDemoName(e.target.value)}
                    className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">Demo Leverage</label>
                  <select
                    value={demoLeverage}
                    onChange={e => setDemoLeverage(e.target.value)}
                    className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-blue-500 font-mono"
                  >
                    <option value="1:500">1:500 (Pro Demo)</option>
                    <option value="1:200">1:200 (Standard)</option>
                    <option value="1:100">1:100 (Conservative)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={demoEmail}
                  onChange={e => setDemoEmail(e.target.value)}
                  className="w-full bg-[#0B1220] border border-slate-700 rounded-lg px-2.5 py-1.5 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <button
                type="submit"
                onClick={() => setSelectedOption('DEMO')}
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors shadow-md shadow-blue-500/20 flex items-center justify-center gap-1.5"
              >
                <span>Launch $1,000 Demo Account</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>

        {/* OPTION B: LIVE TRADING */}
        <div className={`p-6 rounded-2xl border transition-all flex flex-col justify-between ${
          selectedOption === 'LIVE' 
            ? 'bg-[#151F30] border-amber-500 shadow-xl shadow-amber-500/10 ring-1 ring-amber-500' 
            : 'bg-[#111827] border-slate-800 hover:border-slate-700'
        }`}>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 uppercase tracking-wider">
                Option B · Institutional
              </span>
              <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                KYC Verification Required
              </span>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white">Live Account</h2>
              <p className="text-xs text-slate-400 mt-1">
                Institutional & Retail live onboarding. Select Live Trading directly without first opening a demo account.
              </p>
            </div>

            {/* Live Requirements & Safety Notice */}
            <div className="p-3 bg-[#0B1220] border border-slate-800 rounded-xl space-y-1.5 text-xs">
              <div className="flex items-center gap-1.5 text-amber-400 font-semibold">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>Financial Safety Architecture:</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Live trade execution and money deposits are kept strictly disabled until legitimate broker integration, authorized regulatory licenses, and legal terms are confirmed.
              </p>
            </div>

            <ul className="space-y-2 text-xs text-slate-300 pt-1">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Personal, financial, and trading experience profiling</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Identity verification / KYC documentation review</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Professional verification-pending console</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Separate live account ID distinct from demo accounts</span>
              </li>
            </ul>

            <div className="pt-4">
              <button
                type="button"
                onClick={() => {
                  setSelectedOption('LIVE');
                  setLiveModalOpen(true);
                }}
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg transition-colors shadow-md shadow-amber-600/20 flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Apply for Live Account (KYC)</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center text-xs text-slate-400">
        Already registered?{' '}
        <Link to="/login" className="text-blue-400 font-semibold hover:underline">
          Sign In to Existing Account
        </Link>
      </div>

      {/* Live Onboarding Modal */}
      <LiveOnboardingModal
        isOpen={liveModalOpen}
        onClose={() => setLiveModalOpen(false)}
      />
    </div>
  );
};

export const ForgotPasswordPage: React.FC = () => {
  const { addToast } = useToast();
  const [email, setEmail] = useState('');

  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    addToast({
      type: 'info',
      title: 'Reset Link Dispatched',
      message: `Password reset simulation instruction sent to ${email || 'your email'}.`
    });
  };

  return (
    <div className="max-w-md mx-auto px-6 py-16 space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-2xl font-extrabold text-white">Reset Account Password</h1>
        <p className="text-xs text-slate-400">Enter your email to receive recovery instructions.</p>
      </div>

      <form onSubmit={handleReset} className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-4 text-xs">
        <div>
          <label className="block text-slate-300 font-semibold mb-1">Registered Email</label>
          <input
            type="email"
            required
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="trader@company.com"
            className="w-full bg-[#0B1220] border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
          />
        </div>
        <button
          type="submit"
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors"
        >
          Send Recovery Email
        </button>
      </form>

      <div className="text-center text-xs text-slate-400">
        <Link to="/login" className="text-blue-400 hover:underline">Return to Sign In</Link>
      </div>
    </div>
  );
};

export const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12 space-y-6 text-xs text-slate-300 leading-relaxed">
      <h1 className="text-3xl font-extrabold text-white">Privacy Policy</h1>
      <p className="text-slate-400">Effective Date: November 2026</p>
      
      <h2 className="text-base font-bold text-white pt-4">1. Data Collection & Purpose</h2>
      <p>
        NEXTRADE FX is a prototype simulated fintech demonstration platform. Any email addresses, simulated credentials, or account IDs submitted are held in local application state or browser storage solely for prototype demonstration.
      </p>

      <h2 className="text-base font-bold text-white pt-4">2. Cookies & Local State</h2>
      <p>
        We utilize browser localStorage to retain theme preferences and simulated order parameters. No third-party tracking pixels or telemetry engines are embedded.
      </p>
    </div>
  );
};

export const TermsPage: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12 space-y-6 text-xs text-slate-300 leading-relaxed">
      <h1 className="text-3xl font-extrabold text-white">Terms & Conditions</h1>
      <p className="text-slate-400">Effective Date: November 2026</p>

      <h2 className="text-base font-bold text-white pt-4">1. Software Prototype Terms</h2>
      <p>
        By accessing the NEXTRADE FX web application, you acknowledge that this portal is strictly a non-commercial software simulation. No real trades, bank accounts, or financial transactions are executed.
      </p>

      <h2 className="text-base font-bold text-white pt-4">2. Intellectual Property</h2>
      <p>
        All interface components, chart visualizations, brand marks, and layout architectures are proprietary prototype assets of NEXTRADE FX Platform Technologies.
      </p>
    </div>
  );
};

export const RiskDisclosurePage: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto px-6 py-12 space-y-6 text-xs text-slate-300 leading-relaxed">
      <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-sm">Regulatory Notice & Financial Risk Statement</h3>
          <p className="text-xs text-amber-200/90 mt-1">
            Foreign exchange and CFD trading on real margin carries a high level of risk and may not be suitable for all investors.
          </p>
        </div>
      </div>

      <h1 className="text-3xl font-extrabold text-white pt-2">Full Risk Disclosure</h1>

      <h2 className="text-base font-bold text-white">1. Simulated Market Data</h2>
      <p>
        All market pricing, bid/ask spreads, currency quotes, tick fluctuations, and simulated order fills displayed across the NEXTRADE FX platform are algorithmic approximations created for educational and interface testing purposes only. Past simulated performance is no indicator of real market results.
      </p>

      <h2 className="text-base font-bold text-white">2. High Leverage Risk</h2>
      <p>
        Leverage accelerates both potential gains and potential losses. In real financial markets, trading with high leverage (such as 1:500) can result in the rapid loss of your entire deposited capital.
      </p>

      <h2 className="text-base font-bold text-white">3. Non-Advisory Nature</h2>
      <p>
        NEXTRADE FX does not offer personal financial advice, investment recommendations, or asset management. Any commentary, technical chart analysis, or signals displayed are for illustrative purposes only.
      </p>
    </div>
  );
};
