import React, { useState } from 'react';
import { useToast } from '../../contexts/ToastContext';
import { useTrading } from '../../contexts/TradingContext';
import { 
  UserCheck, Shield, Bell, FileText, LifeBuoy, 
  User, Settings, Upload, CheckCircle, AlertCircle, Clock, 
  Key, Smartphone, Laptop, Lock, RefreshCw, Send, Plus 
} from 'lucide-react';

export const KycPage: React.FC = () => {
  const { addToast } = useToast();
  const [docType, setDocType] = useState('PASSPORT');
  const [docNumber, setDocNumber] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    addToast({
      type: 'success',
      title: 'KYC Documents Uploaded',
      message: 'Simulated compliance submission received. Verification status updated to Pending.'
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Identity Verification (KYC)</h2>
        <p className="text-xs text-slate-400 mt-1">
          Simulated anti-money laundering and customer identification compliance portal.
        </p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-6">
        <div className="flex items-center justify-between p-4 bg-[#151F30] border border-slate-700/80 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">Verification Status: {submitted ? 'PENDING REVIEW' : 'TIER 1 DEMO UNVERIFIED'}</div>
              <div className="text-[11px] text-slate-400">
                {submitted ? 'Compliance team is reviewing your documents.' : 'Submit a government-issued photo ID to upgrade demo trading limits.'}
              </div>
            </div>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
            {submitted ? 'UNDER REVIEW' : 'PENDING'}
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Document Category</label>
            <select
              value={docType}
              onChange={e => setDocType(e.target.value)}
              className="w-full bg-[#0B1220] border border-slate-700 rounded p-2 text-white focus:outline-none focus:border-blue-500"
            >
              <option value="PASSPORT">International Passport</option>
              <option value="NATIONAL_ID">National Identity Card</option>
              <option value="DRIVING_LICENSE">Driver's License</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Document Number</label>
            <input
              type="text"
              required
              value={docNumber}
              onChange={e => setDocNumber(e.target.value)}
              placeholder="e.g. GB-99218204"
              className="w-full bg-[#0B1220] border border-slate-700 rounded p-2 text-white font-mono focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="border-2 border-dashed border-slate-700 hover:border-slate-600 rounded-xl p-8 text-center cursor-pointer bg-[#0B1220]/50 transition-colors">
            <Upload className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-xs font-semibold text-white">Click or drag simulated document file here</div>
            <div className="text-[11px] text-slate-500 mt-1">PNG, JPG or PDF up to 10MB (Test demo file)</div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow-sm"
          >
            Submit for Automated Compliance Review
          </button>
        </form>
      </div>
    </div>
  );
};

export const NotificationsPage: React.FC = () => {
  const notifs = [
    { id: 1, title: 'Simulated Order Executed', desc: 'BUY 1.00 Lot EUR/USD filled at 1.08437', time: '10 mins ago', type: 'order' },
    { id: 2, title: 'High-Impact Economic Release', desc: 'Core PCE Price Index printed 0.3% MoM, matching consensus', time: '1 hour ago', type: 'news' },
    { id: 3, title: 'Demo Deposit Credited', desc: '+$10,000 USD credited to account #NX-809214', time: '3 hours ago', type: 'finance' },
    { id: 4, title: 'Margin Cushion Alert', desc: 'Free margin above 90% threshold across all demo accounts', time: 'Yesterday', type: 'security' },
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Notifications & Alerts</h2>
        <p className="text-xs text-slate-400 mt-1">System status updates, fill confirmations, and macro alerts.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl divide-y divide-slate-800/80">
        {notifs.map(n => (
          <div key={n.id} className="p-4 flex items-start gap-3 hover:bg-[#151F30]/40 transition-colors">
            <div className="w-8 h-8 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center shrink-0 mt-0.5">
              <Bell className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">{n.title}</span>
                <span className="text-[10px] text-slate-500">{n.time}</span>
              </div>
              <div className="text-xs text-slate-300 mt-0.5">{n.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const ReportsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Performance Analytics & Risk Reports</h2>
        <p className="text-xs text-slate-400 mt-1">Quantitative breakdowns of simulated returns, Sharpe ratio, and drawdown metrics.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Sharpe Ratio</div>
          <div className="text-xl font-bold font-mono text-emerald-400 mt-1">2.14</div>
          <div className="text-[10px] text-slate-500">Risk-adjusted returns</div>
        </div>
        <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Max Drawdown</div>
          <div className="text-xl font-bold font-mono text-rose-400 mt-1">-4.82%</div>
          <div className="text-[10px] text-slate-500">Peak-to-trough decline</div>
        </div>
        <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Profit Factor</div>
          <div className="text-xl font-bold font-mono text-blue-400 mt-1">1.88</div>
          <div className="text-[10px] text-slate-500">Gross profit / gross loss</div>
        </div>
        <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl">
          <div className="text-[11px] text-slate-400 uppercase font-semibold">Average Trade Duration</div>
          <div className="text-xl font-bold font-mono text-white mt-1">4h 18m</div>
          <div className="text-[10px] text-slate-500">Intraday / Swing model</div>
        </div>
      </div>

      <div className="p-6 bg-[#111827] border border-slate-800 rounded-xl space-y-4">
        <h3 className="text-sm font-bold text-white">Simulated Monthly P/L Distribution</h3>
        <div className="grid grid-cols-6 sm:grid-cols-12 gap-2 text-center text-xs font-mono">
          {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((m, idx) => {
            const pnl = [2.4, 3.1, -1.2, 4.5, 1.8, -0.8, 3.9, 2.1, 4.2, 1.9, 2.8, 0.0][idx];
            return (
              <div key={m} className="p-2.5 bg-[#151F30] border border-slate-800 rounded-lg">
                <div className="text-[10px] text-slate-400 font-sans">{m}</div>
                <div className={`font-bold mt-1 ${pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {pnl >= 0 ? '+' : ''}{pnl}%
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export const TicketsPage: React.FC = () => {
  const { addToast } = useToast();
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('Trading Execution');
  const [message, setMessage] = useState('');
  const [created, setCreated] = useState(false);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setCreated(true);
    addToast({
      type: 'success',
      title: 'Ticket Submitted',
      message: `Support ticket #${Math.floor(1000 + Math.random() * 9000)} created. Desk will reply shortly.`
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Client Support Tickets</h2>
        <p className="text-xs text-slate-400 mt-1">Direct communication channel with technical dealing desk and compliance.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-5">
        <h3 className="text-sm font-bold text-white">Create New Inquest</h3>
        <form onSubmit={handleCreate} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Subject</label>
            <input
              type="text"
              required
              value={subject}
              onChange={e => setSubject(e.target.value)}
              placeholder="e.g. Inquire about simulated spread latency on Gold"
              className="w-full bg-[#0B1220] border border-slate-700 rounded p-2 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Department</label>
            <select
              value={category}
              onChange={e => setCategory(e.target.value)}
              className="w-full bg-[#0B1220] border border-slate-700 rounded p-2 text-white focus:outline-none focus:border-blue-500"
            >
              <option value="Trading Execution">Dealing Desk & Order Execution</option>
              <option value="Platform & Technical">Web Terminal & Charting Tech</option>
              <option value="Account Verification">KYC & Compliance Verification</option>
              <option value="Billing & Transfer">Demo Wallet & Ledger</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Message Details</label>
            <textarea
              rows={4}
              required
              value={message}
              onChange={e => setMessage(e.target.value)}
              placeholder="Provide context or instrument symbol..."
              className="w-full bg-[#0B1220] border border-slate-700 rounded p-2 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Submit Ticket</span>
          </button>
        </form>
      </div>
    </div>
  );
};

export const ProfilePage: React.FC = () => {
  const { activeAccount } = useTrading();
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Trader Profile</h2>
        <p className="text-xs text-slate-400 mt-1">Institutional account holder credentials and client identifier.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-4 text-xs">
        <div className="flex items-center gap-4 pb-4 border-b border-slate-800">
          <div className="w-14 h-14 rounded-full bg-blue-600 text-white font-bold text-lg flex items-center justify-center">
            JD
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Johnathan Doe</h3>
            <div className="text-slate-400 font-mono">CLIENT-ID: NX-USR-99214</div>
            <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">Verified Demo Trader</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 pt-2">
          <div>
            <span className="text-slate-500 block text-[11px]">Primary Email</span>
            <span className="text-white font-semibold">demo.trader@nextrade.io</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Country of Residence</span>
            <span className="text-white font-semibold">United Kingdom (FCA Demo Sandbox)</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Active Account</span>
            <span className="text-white font-mono font-bold">{activeAccount.accountNumber}</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Execution Server</span>
            <span className="text-white font-mono">{activeAccount.server}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export const AccountSettingsPage: React.FC = () => {
  const { addToast } = useToast();
  const [language, setLanguage] = useState('English');
  const [tz, setTz] = useState('GMT+0 (London)');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    addToast({ type: 'success', title: 'Settings Saved', message: 'Trader terminal preferences updated.' });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Account Settings</h2>
        <p className="text-xs text-slate-400 mt-1">Platform locale, timezone alignment, and default order execution preferences.</p>
      </div>

      <form onSubmit={handleSave} className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-4 text-xs">
        <div>
          <label className="block text-slate-300 font-semibold mb-1">Timezone Display</label>
          <select
            value={tz}
            onChange={e => setTz(e.target.value)}
            className="w-full bg-[#0B1220] border border-slate-700 rounded p-2 text-white focus:outline-none focus:border-blue-500"
          >
            <option value="GMT+0 (London)">GMT+0 (London Financial Time)</option>
            <option value="EST (New York)">EST (New York Market Open)</option>
            <option value="JST (Tokyo)">JST (Tokyo Asian Session)</option>
          </select>
        </div>

        <div>
          <label className="block text-slate-300 font-semibold mb-1">One-Click Trading Confirmation</label>
          <label className="flex items-center gap-2 cursor-pointer mt-1 text-slate-300">
            <input type="checkbox" defaultChecked className="rounded bg-slate-900 border-slate-700 text-blue-600" />
            <span>Enable instant one-click simulated order execution in Terminal</span>
          </label>
        </div>

        <button
          type="submit"
          className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold transition-colors"
        >
          Save Preferences
        </button>
      </form>
    </div>
  );
};

export const SecuritySettingsPage: React.FC = () => {
  const { addToast } = useToast();
  const [twoFactor, setTwoFactor] = useState(true);

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white">Security & 2-Factor Authentication</h2>
        <p className="text-xs text-slate-400 mt-1">Protect your demo account credentials and configure API access keys.</p>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-5 text-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <div className="text-sm font-bold text-white">Two-Factor Authentication (TOTP)</div>
            <div className="text-slate-400 text-xs mt-0.5">Google Authenticator / YubiKey authentication required on session start.</div>
          </div>
          <button
            onClick={() => {
              setTwoFactor(!twoFactor);
              addToast({ type: 'info', title: '2FA Updated', message: `Two-factor authentication ${!twoFactor ? 'enabled' : 'disabled'}.` });
            }}
            className={`px-3 py-1.5 rounded font-bold transition-colors ${
              twoFactor ? 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
            }`}
          >
            {twoFactor ? 'Active / Protected' : 'Enable 2FA'}
          </button>
        </div>

        <div>
          <h4 className="text-xs font-bold text-white mb-2">Active Login Sessions</h4>
          <div className="space-y-2">
            <div className="p-3 bg-[#0B1220] border border-slate-800 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Laptop className="w-4 h-4 text-blue-400" />
                <div>
                  <div className="font-bold text-white">Chrome on macOS (Current Session)</div>
                  <div className="text-[11px] text-slate-500">London, UK · IP 82.165.41.12</div>
                </div>
              </div>
              <span className="text-[10px] text-emerald-400 font-semibold uppercase">ONLINE</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
