import React, { useState } from 'react';
import { useTrading } from '../../contexts/TradingContext';
import { useToast } from '../../contexts/ToastContext';
import { 
  Layers, ShieldCheck, Plus, CheckCircle, RefreshCw, 
  ArrowUpRight, ShieldAlert, Clock, AlertCircle, FileText, ArrowRight 
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { ResetDemoModal } from '../../components/common/ResetDemoModal';
import { LiveOnboardingModal } from '../../components/account/LiveOnboardingModal';

export const TradingAccountsPage: React.FC = () => {
  const { 
    accounts, activeAccount, switchAccount, 
    createDemoAccount, setResetModalOpen, liveApplication 
  } = useTrading();
  const { addToast } = useToast();

  const [activeTab, setActiveTab] = useState<'demo' | 'live'>('demo');
  const [createModal, setCreateModal] = useState(false);
  const [newAccType, setNewAccType] = useState('Raw ECN Demo');
  const [newLeverage, setNewLeverage] = useState('1:500');
  const [liveOnboardingOpen, setLiveOnboardingOpen] = useState(false);

  const demoAccounts = accounts.filter(a => a.mode === 'DEMO');
  const liveAccounts = accounts.filter(a => a.mode === 'LIVE');

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    createDemoAccount({
      type: newAccType,
      leverage: newLeverage
    });
    setCreateModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h2 className="text-xl font-bold text-white">Trading Accounts Management</h2>
            <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-semibold uppercase">
              Isolated Environments
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Switch between simulated $1,000 practice accounts and live institutional onboarding consoles.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setCreateModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition-colors shadow-sm shadow-blue-500/20"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Open New Demo ($1,000)</span>
          </button>
          <button
            onClick={() => setLiveOnboardingOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold transition-colors shadow-sm shadow-amber-600/20"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Apply for Live Account</span>
          </button>
        </div>
      </div>

      {/* Tabs: Demo Accounts vs Live Account */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('demo')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'demo'
              ? 'bg-blue-600 text-white'
              : 'text-slate-400 hover:text-white bg-[#151F30]'
          }`}
        >
          <span>Demo Accounts ({demoAccounts.length})</span>
          <span className="text-[10px] px-1.5 py-0.2 bg-white/20 rounded font-mono">$1,000 Starting Rule</span>
        </button>
        <button
          onClick={() => setActiveTab('live')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'live'
              ? 'bg-amber-600 text-white'
              : 'text-slate-400 hover:text-white bg-[#151F30]'
          }`}
        >
          <span>Live Account Console ({liveAccounts.length})</span>
          <span className="text-[10px] px-1.5 py-0.2 bg-white/20 rounded">KYC / Broker Verification</span>
        </button>
      </div>

      {/* TAB 1: DEMO ACCOUNTS */}
      {activeTab === 'demo' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {demoAccounts.map(acc => {
              const isActive = acc.id === activeAccount.id;

              return (
                <div
                  key={acc.id}
                  className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                    isActive
                      ? 'bg-[#151F30] border-blue-500/60 shadow-lg shadow-blue-500/10 ring-1 ring-blue-500/50'
                      : 'bg-[#111827] border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-white text-base">#{acc.accountNumber}</span>
                        {isActive && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold uppercase">
                            ACTIVE DEMO
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-slate-400 font-mono">{acc.server}</span>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-300 font-medium mb-4">
                      <span>{acc.type}</span>
                      <span className="text-[11px] text-blue-400 font-mono">Rule: $1k Practice</span>
                    </div>

                    <div className="space-y-2 py-3 border-y border-slate-800 text-xs tabular-nums">
                      <div className="flex justify-between text-slate-400">
                        <span>Balance (DEMO):</span>
                        <span className="font-bold text-white font-mono">${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Equity:</span>
                        <span className="font-bold text-white font-mono">${acc.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Used Margin:</span>
                        <span className="font-mono text-slate-300">${acc.margin.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Free Margin:</span>
                        <span className="font-bold text-emerald-400 font-mono">${acc.freeMargin.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between text-slate-400">
                        <span>Configured Leverage:</span>
                        <span className="font-mono text-white">{acc.leverage}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 flex items-center gap-2 mt-4">
                    {isActive ? (
                      <Link
                        to="/trader/terminal"
                        className="flex-1 py-2 text-center rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1 shadow-sm"
                      >
                        <span>Trade in Terminal</span>
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </Link>
                    ) : (
                      <button
                        onClick={() => switchAccount(acc.id)}
                        className="flex-1 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
                      >
                        Select Account
                      </button>
                    )}

                    <button
                      onClick={() => {
                        if (!isActive) switchAccount(acc.id);
                        setResetModalOpen(true);
                      }}
                      className="px-3 py-2 rounded-lg bg-[#0B1220] border border-amber-500/30 text-amber-400 hover:bg-amber-500/10 text-xs font-semibold transition-colors flex items-center gap-1"
                      title="Reset demo account to initial $1,000 USD virtual balance"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>Reset</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: LIVE ACCOUNT CONSOLE */}
      {activeTab === 'live' && (
        <div className="space-y-6">
          {/* Institutional Broker & Safety Notice */}
          <div className="p-5 bg-[#151F30] border border-amber-500/40 rounded-xl space-y-3">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <ShieldAlert className="w-5 h-5 shrink-0" />
              <span>Live Trading Regulatory & Broker Connectivity Notice</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              In accordance with institutional risk management and compliance, live market execution and deposit processing are disabled until authorized broker connectivity and identity KYC verifications are finalized.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Live Account Details Card (7 cols) */}
            <div className="lg:col-span-7 bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-white text-base">
                    #{liveAccounts[0]?.accountNumber || 'NX-LIVE-10492'}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 font-semibold uppercase">
                    {liveAccounts[0]?.status || 'PENDING VERIFICATION'}
                  </span>
                </div>
                <span className="text-xs text-slate-400 font-mono">NEXTRADE-Live-Prime</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs tabular-nums font-mono py-2">
                <div className="p-3 bg-[#0B1220] rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-sans">Live Balance</span>
                  <span className="text-base font-bold text-white">$0.00 USD</span>
                </div>
                <div className="p-3 bg-[#0B1220] rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-sans">Live Equity</span>
                  <span className="text-base font-bold text-white">$0.00 USD</span>
                </div>
                <div className="p-3 bg-[#0B1220] rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-sans">Leverage</span>
                  <span className="text-base font-bold text-white">1:100</span>
                </div>
                <div className="p-3 bg-[#0B1220] rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block font-sans">Execution</span>
                  <span className="text-xs font-semibold text-amber-400">Disabled (Audit)</span>
                </div>
              </div>

              <div className="p-4 bg-[#0B1220] border border-slate-800 rounded-xl space-y-2 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Application Reference:</span>
                  <span className="font-mono font-bold text-white">{liveApplication.id}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">KYC Verification Status:</span>
                  <span className="text-amber-400 font-semibold uppercase">{liveApplication.status.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Document Type:</span>
                  <span className="text-white">{liveApplication.idType} ({liveApplication.idNumber || 'Verified'})</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Submitted Timestamp:</span>
                  <span className="font-mono text-slate-400">{liveApplication.submittedAt}</span>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setLiveOnboardingOpen(true)}
                  className="flex-1 py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg text-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>View / Edit Onboarding Application</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (liveAccounts[0]) switchAccount(liveAccounts[0].id);
                  }}
                  className={`py-2.5 px-4 rounded-lg text-xs font-bold transition-colors ${
                    activeAccount.mode === 'LIVE'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                  }`}
                >
                  {activeAccount.mode === 'LIVE' ? 'Currently Active' : 'Select Live Workspace'}
                </button>
              </div>
            </div>

            {/* Checklist & Approval Steps (5 cols) */}
            <div className="lg:col-span-5 bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Approval Pathway</h3>
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-[#0B1220] rounded-lg border border-emerald-500/30 flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">1. Account Registration</div>
                    <div className="text-[11px] text-slate-400">User registered with primary credentials.</div>
                  </div>
                </div>

                <div className="p-3 bg-[#0B1220] rounded-lg border border-amber-500/30 flex items-start gap-3">
                  <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-white">2. Institutional KYC Document Review</div>
                    <div className="text-[11px] text-slate-400">Compliance team verification (24-48 hours).</div>
                  </div>
                </div>

                <div className="p-3 bg-[#0B1220] rounded-lg border border-slate-800 flex items-start gap-3 opacity-60">
                  <AlertCircle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-slate-300">3. Prime Liquidity Bridge Authorization</div>
                    <div className="text-[11px] text-slate-500">Live FIX 4.4 / ECN execution gateway allocation.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Account Specifications Matrix */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl p-5">
        <h3 className="text-sm font-bold text-white mb-3">NEXTRADE FX Account Tier Specifications</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[650px]">
            <thead className="text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Tier Name</th>
                <th className="py-2.5 px-3">Environment</th>
                <th className="py-2.5 px-3">Starting Capital</th>
                <th className="py-2.5 px-3">Spreads From</th>
                <th className="py-2.5 px-3">Commission / Lot</th>
                <th className="py-2.5 px-3">Max Leverage</th>
                <th className="py-2.5 px-3">Execution Mode</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              <tr className="hover:bg-[#151F30]/50">
                <td className="py-2.5 px-3 font-bold text-white font-sans">Raw ECN Demo</td>
                <td className="py-2.5 px-3 text-blue-400 font-sans">Demo Practice</td>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">$1,000 USD</td>
                <td className="py-2.5 px-3 text-blue-400 font-bold">0.0 pips</td>
                <td className="py-2.5 px-3 text-slate-300">$3.50</td>
                <td className="py-2.5 px-3 text-slate-300">1:500</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Simulated Market</td>
              </tr>
              <tr className="hover:bg-[#151F30]/50">
                <td className="py-2.5 px-3 font-bold text-white font-sans">Standard Demo</td>
                <td className="py-2.5 px-3 text-blue-400 font-sans">Demo Practice</td>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">$1,000 USD</td>
                <td className="py-2.5 px-3 text-blue-400 font-bold">1.0 pips</td>
                <td className="py-2.5 px-3 text-slate-300">$0.00</td>
                <td className="py-2.5 px-3 text-slate-300">1:200</td>
                <td className="py-2.5 px-3 text-slate-400 font-sans">Simulated Market</td>
              </tr>
              <tr className="hover:bg-[#151F30]/50">
                <td className="py-2.5 px-3 font-bold text-amber-400 font-sans">Institutional ECN Live</td>
                <td className="py-2.5 px-3 text-amber-400 font-sans">Live Onboarding</td>
                <td className="py-2.5 px-3 text-slate-400">$0 (Awaiting Bridge)</td>
                <td className="py-2.5 px-3 text-amber-400 font-bold">0.0 pips</td>
                <td className="py-2.5 px-3 text-slate-300">$2.00</td>
                <td className="py-2.5 px-3 text-slate-300">1:100</td>
                <td className="py-2.5 px-3 text-amber-400 font-sans">Pending Live Broker</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Create New Demo Account Modal */}
      {createModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-[#111827] border border-blue-500/40 rounded-2xl p-6 shadow-2xl relative space-y-4">
            <h3 className="text-base font-bold text-white">Open New Simulated Demo Account</h3>
            <p className="text-xs text-slate-400">
              In accordance with our platform rules, every new demo account starts with exactly <strong className="text-emerald-400">$1,000 USD</strong> virtual balance.
            </p>

            <form onSubmit={handleCreateAccount} className="space-y-4 text-xs pt-2">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Account Tier</label>
                <select
                  value={newAccType}
                  onChange={e => setNewAccType(e.target.value)}
                  className="w-full bg-[#0B1220] border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="Raw ECN Demo">Raw ECN Demo (0.0 pips + commission)</option>
                  <option value="Standard Demo">Standard Demo (Spread from 1.0 pips, 0 commission)</option>
                  <option value="Institutional Pro Demo">Institutional Pro Demo (Custom liquidity feed)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Leverage Ratio</label>
                <select
                  value={newLeverage}
                  onChange={e => setNewLeverage(e.target.value)}
                  className="w-full bg-[#0B1220] border border-slate-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500 font-mono"
                >
                  <option value="1:500">1:500 (Aggressive / High Margin Free)</option>
                  <option value="1:200">1:200 (Balanced Institutional)</option>
                  <option value="1:100">1:100 (Conservative)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Initial Virtual Balance</label>
                <input
                  type="text"
                  disabled
                  value="$1,000.00 USD (Fixed Practice Rule)"
                  className="w-full bg-[#0B1220]/60 border border-slate-800 rounded-lg p-2.5 text-emerald-400 font-mono font-bold"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setCreateModal(false)}
                  className="px-4 py-2 rounded-lg border border-slate-700 text-slate-300 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg shadow-md shadow-blue-500/20"
                >
                  Create $1,000 Demo Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Global Modals */}
      <ResetDemoModal />
      <LiveOnboardingModal
        isOpen={liveOnboardingOpen}
        onClose={() => setLiveOnboardingOpen(false)}
      />
    </div>
  );
};
