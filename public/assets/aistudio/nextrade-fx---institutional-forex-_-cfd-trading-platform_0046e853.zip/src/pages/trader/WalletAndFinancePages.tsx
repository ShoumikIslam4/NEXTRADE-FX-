import React, { useState } from 'react';
import { useTrading } from '../../contexts/TradingContext';
import { useToast } from '../../contexts/ToastContext';
import { 
  Wallet, ArrowDownCircle, ArrowUpCircle, Receipt, 
  CreditCard, Building2, Bitcoin, CheckCircle2, AlertCircle, 
  RefreshCw, ArrowRight, ShieldCheck, Lock, AlertTriangle, Info
} from 'lucide-react';

export const WalletPage: React.FC = () => {
  const { activeAccount, accounts, transactions, depositDemoFunds, setResetModalOpen } = useTrading();

  const isLive = activeAccount.mode === 'LIVE';
  const demoAccounts = accounts.filter(a => a.mode === 'DEMO');
  const liveAccounts = accounts.filter(a => a.mode === 'LIVE');

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-white">Wallet & Balances</h2>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
              isLive ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
            }`}>
              {isLive ? 'Live Console' : 'Demo Practice ($1,000 Cap)'}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Simulated capital allocation and risk management ledger across Nextrade accounts.
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          {!isLive && (
            <>
              <button
                onClick={() => {
                  if (activeAccount.balance >= 1000) {
                    setResetModalOpen(true);
                  } else {
                    depositDemoFunds(1000 - activeAccount.balance, 'Practice Top-Up');
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold transition-colors shadow-sm shadow-emerald-950"
              >
                <ArrowDownCircle className="w-3.5 h-3.5" />
                <span>Top-up to $1,000 Demo</span>
              </button>
              <button
                onClick={() => setResetModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-[#151F30] border border-slate-700 hover:border-rose-500/50 hover:text-rose-400 text-slate-300 rounded-lg text-xs font-semibold transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset Demo ($1,000)</span>
              </button>
            </>
          )}

          {isLive && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-lg text-xs font-medium">
              <Lock className="w-3.5 h-3.5" />
              <span>Real Deposits Locked (Pending KYC)</span>
            </div>
          )}
        </div>
      </div>

      {/* Strict $1,000 Rule Notice Banner for Demo */}
      {!isLive && (
        <div className="p-3.5 rounded-xl bg-blue-950/30 border border-blue-500/20 flex items-start gap-3">
          <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed text-slate-300">
            <span className="font-semibold text-white">Institutional $1,000 Demo Capital Protocol:</span> Every demo practice account is strictly anchored to a $1,000 USD virtual capital baseline to instill disciplined lot-sizing (0.01 to 20 lots). Manual deposits cannot raise the balance beyond $1,000. If your balance is drawn down, click <strong className="text-blue-300">Reset Demo ($1,000)</strong> to restore the account to exactly $1,000.
          </div>
        </div>
      )}

      {/* Main Balances Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="p-5 rounded-xl bg-[#111827] border border-slate-800">
          <div className="text-xs text-slate-400 uppercase font-semibold">Active Account Balance</div>
          <div className="text-2xl font-bold font-mono text-white mt-2">
            ${activeAccount.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {isLive ? 'Live Account #NX-LIVE-10492 (Unfunded)' : `Demo Account #${activeAccount.accountNumber}`}
          </div>
        </div>

        <div className="p-5 rounded-xl bg-[#111827] border border-slate-800">
          <div className="text-xs text-slate-400 uppercase font-semibold">Active Free Margin</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-2">
            ${activeAccount.freeMargin.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {isLive ? 'Requires broker verification' : 'Available for practice margin collateral'}
          </div>
        </div>

        <div className="p-5 rounded-xl bg-[#111827] border border-slate-800">
          <div className="text-xs text-slate-400 uppercase font-semibold">Current Floating P&amp;L</div>
          <div className={`text-2xl font-bold font-mono mt-2 ${activeAccount.floatingProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {activeAccount.floatingProfit >= 0 ? '+' : ''}${activeAccount.floatingProfit.toFixed(2)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Equity: ${activeAccount.equity.toFixed(2)} USD
          </div>
        </div>
      </div>

      {/* Account Balances Table */}
      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Accounts Breakdown</h3>
          <span className="text-xs text-slate-400">Total Accounts: {accounts.length}</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs tabular-nums font-mono">
            <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4">Account Number</th>
                <th className="py-2.5 px-4">Mode</th>
                <th className="py-2.5 px-4">Type</th>
                <th className="py-2.5 px-4">Leverage</th>
                <th className="py-2.5 px-4">Balance</th>
                <th className="py-2.5 px-4">Equity</th>
                <th className="py-2.5 px-4">Free Margin</th>
                <th className="py-2.5 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {accounts.map(acc => (
                <tr key={acc.id} className={`hover:bg-[#151F30]/60 ${acc.id === activeAccount.id ? 'bg-blue-900/10' : ''}`}>
                  <td className="py-2.5 px-4 font-bold text-white font-mono flex items-center gap-2">
                    {acc.accountNumber}
                    {acc.id === activeAccount.id && (
                      <span className="text-[10px] bg-blue-500 text-white px-1.5 py-0.2 rounded font-sans">Active</span>
                    )}
                  </td>
                  <td className="py-2.5 px-4 font-sans">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                      acc.mode === 'LIVE' ? 'bg-amber-500/20 text-amber-300' : 'bg-blue-500/20 text-blue-300'
                    }`}>
                      {acc.mode}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 font-sans text-slate-300">{acc.type}</td>
                  <td className="py-2.5 px-4 text-slate-400">{acc.leverage}</td>
                  <td className="py-2.5 px-4 text-white font-bold">${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                  <td className="py-2.5 px-4 text-white font-bold">${acc.equity.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                  <td className="py-2.5 px-4 text-emerald-400 font-bold">${acc.freeMargin.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                  <td className="py-2.5 px-4 text-right font-sans">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-semibold ${
                      acc.status === 'ACTIVE' 
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                    }`}>
                      {acc.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export const DepositPage: React.FC = () => {
  const { depositDemoFunds, activeAccount, setResetModalOpen } = useTrading();
  const [selectedMethod, setSelectedMethod] = useState('wire');
  const [amount, setAmount] = useState<number>(250);

  const isLive = activeAccount.mode === 'LIVE';
  const remainingAllowance = Math.max(0, 1000 - activeAccount.balance);

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLive) return;

    const methodNames: Record<string, string> = {
      wire: 'Simulated Practice Wire',
      card: 'Simulated Card Gateway',
      crypto: 'Simulated USDT (ERC-20)'
    };
    depositDemoFunds(amount, methodNames[selectedMethod] || 'Demo Credit');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-white">Deposit Portal</h2>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
            isLive ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
          }`}>
            {isLive ? 'Live Account (Locked)' : 'Demo Practice ($1,000 Cap)'}
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          {isLive 
            ? 'Live deposits are disabled until KYC and institutional broker connectivity are finalized.'
            : `Add practice funds to demo account #${activeAccount.accountNumber} up to the $1,000 virtual balance ceiling.`
          }
        </p>
      </div>

      {/* Live Account Lock Banner */}
      {isLive && (
        <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-amber-400 font-bold text-sm">
            <Lock className="w-5 h-5 shrink-0" />
            <span>Live Account Deposits Are Restricted</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Your Live Account (<span className="font-mono text-white">#{activeAccount.accountNumber}</span>) is currently under <strong>Verification Pending</strong> status with our institutional clearing partners. In compliance with simulated FinTech platform safety protocols, no real currency transactions or credit card debits are permitted.
          </p>
          <div className="p-3 bg-amber-500/10 rounded-lg text-xs text-amber-300 flex items-center justify-between">
            <span>To practice trading immediately with $1,000 virtual capital:</span>
            <span className="font-semibold text-white underline">Switch to Demo Account</span>
          </div>
        </div>
      )}

      {/* Demo Account Form */}
      {!isLive && (
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-6">
          {/* $1,000 Cap Notice */}
          <div className="p-3.5 bg-blue-950/20 border border-blue-500/20 rounded-lg flex items-start gap-2.5 text-xs text-slate-300">
            <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white">$1,000 Virtual Balance Limit:</span> Current Demo Balance: <span className="font-mono text-white font-bold">${activeAccount.balance.toFixed(2)} USD</span>. 
              {remainingAllowance > 0 ? (
                <> You can deposit up to <span className="font-mono text-emerald-400 font-bold">${remainingAllowance.toFixed(2)} USD</span> to reach the $1,000 baseline.</>
              ) : (
                <> Your account is already at or above $1,000 USD. If you want to restart, use the <strong className="text-blue-300">Reset Demo Account</strong> option below.</>
              )}
            </div>
          </div>

          {/* Method selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">Select Simulated Practice Gateway</label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'wire', title: 'Simulated Wire', icon: Building2 },
                { id: 'card', title: 'Virtual Card', icon: CreditCard },
                { id: 'crypto', title: 'Simulated USDT', icon: Bitcoin }
              ].map(m => {
                const Icon = m.icon;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setSelectedMethod(m.id)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      selectedMethod === m.id
                        ? 'border-blue-500 bg-blue-600/15 text-white'
                        : 'border-slate-800 bg-[#151F30] text-slate-400 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4 mb-2 text-blue-400" />
                    <div className="text-xs font-bold">{m.title}</div>
                    <div className="text-[10px] text-slate-500">Virtual Demo · Instant</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amount presets adhering to $1,000 rule */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">Practice Top-Up Presets (USD)</label>
            <div className="grid grid-cols-4 gap-2 mb-3">
              {[100, 250, 500, remainingAllowance].filter(v => v > 0).map((val, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setAmount(Math.min(val, remainingAllowance))}
                  className={`py-2 rounded font-mono text-xs font-bold transition-colors ${
                    amount === val ? 'bg-blue-600 text-white' : 'bg-[#151F30] text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {val === remainingAllowance ? `Fill to $1,000 (+$${val.toFixed(0)})` : `+$${val}`}
                </button>
              ))}
            </div>

            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-500 text-sm">$</span>
              <input
                type="number"
                min="10"
                max={Math.max(10, remainingAllowance)}
                value={amount}
                onChange={e => setAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#0B1220] border border-slate-700 rounded pl-7 pr-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="p-3 bg-[#0B1220] border border-slate-800 rounded-lg text-xs space-y-1">
            <div className="flex justify-between text-slate-400">
              <span>Target Account:</span>
              <span className="font-mono text-white font-bold">{activeAccount.accountNumber} ({activeAccount.type})</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Simulated Execution:</span>
              <span className="text-emerald-400 font-semibold">Immediate Balance Credit</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleDeposit}
              disabled={remainingAllowance <= 0}
              className={`flex-1 py-2.5 rounded-lg text-white font-bold text-xs transition-colors shadow-md ${
                remainingAllowance <= 0
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/20'
              }`}
            >
              {remainingAllowance <= 0 
                ? 'Balance Already at $1,000 Max' 
                : `Credit $${amount.toLocaleString()} USD Demo Funds`
              }
            </button>

            <button
              type="button"
              onClick={() => setResetModalOpen(true)}
              className="px-4 py-2.5 rounded-lg bg-[#151F30] border border-slate-700 hover:border-rose-500 text-slate-300 hover:text-rose-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset to $1,000</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export const WithdrawalPage: React.FC = () => {
  const { withdrawDemoFunds, activeAccount } = useTrading();
  const [amount, setAmount] = useState<number>(200);
  const [destination, setDestination] = useState('');

  const isLive = activeAccount.mode === 'LIVE';

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLive) return;
    withdrawDemoFunds(amount, `Simulated Wire to ${destination || 'Personal Account'}`);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-white">Withdrawal Portal</h2>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
            isLive ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
          }`}>
            {isLive ? 'Live Account (Locked)' : 'Demo Simulation'}
          </span>
        </div>
        <p className="text-xs text-slate-400 mt-1">
          {isLive 
            ? 'Live account withdrawals require active clearing broker liquidity and completed KYC.' 
            : 'Test simulated balance deductions and margin adjustments against your demo account free margin.'
          }
        </p>
      </div>

      {isLive ? (
        <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-amber-400 font-bold text-sm">
            <Lock className="w-5 h-5 shrink-0" />
            <span>Withdrawals Locked — Account Verification Incomplete</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Live Account <span className="font-mono text-white">#{activeAccount.accountNumber}</span> has zero funded collateral and is waiting for KYC authorization. Real-money disbursements are strictly disabled in this simulated prototype environment.
          </p>
        </div>
      ) : (
        <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-6">
          <div className="p-3 bg-[#151F30] border border-slate-800 rounded-lg flex items-center justify-between text-xs">
            <span className="text-slate-400">Available Demo Free Margin:</span>
            <span className="font-mono text-emerald-400 font-bold text-sm">
              ${activeAccount.freeMargin.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD
            </span>
          </div>

          <form onSubmit={handleWithdraw} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Simulated Withdrawal Amount (USD)</label>
              <input
                type="number"
                min="10"
                max={Math.max(10, activeAccount.freeMargin)}
                value={amount}
                onChange={e => setAmount(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#0B1220] border border-slate-700 rounded px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Simulated Destination Bank IBAN / Account</label>
              <input
                type="text"
                required
                value={destination}
                onChange={e => setDestination(e.target.value)}
                placeholder="e.g. GB29 NWBK 6016 1331 9268 19"
                className="w-full bg-[#0B1220] border border-slate-700 rounded px-3 py-2 text-white font-mono focus:outline-none focus:border-blue-500"
              />
            </div>

            <button
              type="submit"
              disabled={activeAccount.freeMargin <= 0}
              className={`w-full py-2.5 rounded-lg text-white font-bold text-xs transition-colors ${
                activeAccount.freeMargin <= 0
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                  : 'bg-blue-600 hover:bg-blue-500'
              }`}
            >
              Submit Simulated Demo Deduction
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export const TransactionsPage: React.FC = () => {
  const { transactions } = useTrading();
  const [filterType, setFilterType] = useState('ALL');

  const filtered = transactions.filter(t => filterType === 'ALL' || t.type === filterType);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">Financial Ledger &amp; Transactions</h2>
          <p className="text-xs text-slate-400 mt-1">Audit log of simulated capital entries, demo resets, and practice balance deductions.</p>
        </div>

        <div className="flex items-center gap-1 bg-[#151F30] p-1 rounded-lg border border-slate-800 text-xs">
          {['ALL', 'DEPOSIT', 'WITHDRAWAL', 'RESET'].map(type => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 rounded font-medium transition-colors ${
                filterType === type ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {type === 'RESET' ? 'DEMO RESET' : type.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-[#111827] border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs tabular-nums font-mono">
            <thead className="bg-[#0B1220] text-slate-400 font-sans border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Transaction ID</th>
                <th className="py-3 px-4">Date &amp; Time</th>
                <th className="py-3 px-4">Account</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Gateway / Method</th>
                <th className="py-3 px-4">Reference</th>
                <th className="py-3 px-4">Amount</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 font-sans">
                    No transactions found for the selected filter.
                  </td>
                </tr>
              ) : (
                filtered.map(t => (
                  <tr key={t.id} className="hover:bg-[#151F30]/60">
                    <td className="py-3 px-4 text-slate-400">{t.id}</td>
                    <td className="py-3 px-4 text-slate-400">{t.date}</td>
                    <td className="py-3 px-4 font-bold text-white">{t.accountNumber}</td>
                    <td className="py-3 px-4 font-semibold">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                        t.type === 'DEPOSIT' ? 'bg-emerald-500/20 text-emerald-400' :
                        t.type === 'RESET' ? 'bg-purple-500/20 text-purple-400' :
                        'bg-rose-500/20 text-rose-400'
                      }`}>
                        {t.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-sans text-slate-200">{t.method}</td>
                    <td className="py-3 px-4 text-slate-500">{t.reference}</td>
                    <td className={`py-3 px-4 font-bold ${
                      t.type === 'DEPOSIT' || t.type === 'RESET' ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {t.type === 'DEPOSIT' || t.type === 'RESET' ? '+' : '-'}${t.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })} {t.currency}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-semibold">
                        {t.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
