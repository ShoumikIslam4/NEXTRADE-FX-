export interface AdminUser {
  id: string;
  name: string;
  email: string;
  country: string;
  registeredDate: string;
  kycStatus: 'APPROVED' | 'PENDING' | 'REJECTED' | 'UNSUBMITTED';
  status: 'ACTIVE' | 'SUSPENDED' | 'FLAGGED';
  totalDemoAccounts: number;
  totalBalanceDemo: number;
  totalVolumeLots: number;
  phone: string;
  ipAddress: string;
}

export interface AdminKycSubmission {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  documentType: 'PASSPORT' | 'DRIVING_LICENSE' | 'NATIONAL_ID';
  documentNumber: string;
  submittedAt: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  notes?: string;
}

export interface AdminPairSetting {
  symbol: string;
  name: string;
  category: string;
  spreadMarkup: number; // in pips
  minSpread: number;
  maxLeverage: number;
  commissionPerLot: number;
  tradingEnabled: boolean;
  swapLong: number;
  swapShort: number;
}

export interface AdminAuditLog {
  id: string;
  timestamp: string;
  staffUser: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  ipAddress: string;
}

export interface StaffMember {
  id: string;
  name: string;
  email: string;
  role: 'Super Administrator' | 'Risk Manager' | 'Compliance Officer' | 'Support Agent' | 'Financial Controller';
  status: 'ACTIVE' | 'INACTIVE';
  twoFactorEnabled: boolean;
  lastLogin: string;
}
